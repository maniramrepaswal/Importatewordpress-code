<?php 
$disarray=array(231,232,233,234,235);
if(!in_array($post->ID,$disarray)) { ?>
<section>
  <div class="client-slider-part <?php echo (is_page() && !is_front_page() && !is_home()) ? "margintop0" : "margintop50" ;  ?> ">
    <div class="container">
      <div class="row">
        <div class="col-sm-100">
          <div id="myCarousel" class="carousel slide" data-ride="carousel">
              
            <?php 
                $args = array("post_type" => "testimonial_slider");
                $query = new WP_Query($args);
                $temp = wp_count_posts();
                $post_count = $temp->publish;
            ?>    
                
                <ol class="carousel-indicators">
                    <?php for($i=0;$i<=$post_count;$i++){?>
                    <li data-target="#myCarousel" data-slide-to="<?php echo $i;?>" <?php if($i==0) echo "class='active'";?>></li>
                    <?php } ?>
                </ol>
            
            
            <!-- Wrapper for slides -->
            <div class="carousel-inner">
                
                <?php
                    $count = 1;
                    while($query->have_posts()):
            		    $query->the_post();
                ?>
                
                <div class="item <?php if($count == 1) echo "active";?>">
                <div class="client_testimonial-sldier">
                    <?php if(has_post_thumbnail()){?>
                    <div class="defalut-img"> 
                        <?php the_post_thumbnail('full', ['class' => 'img-responsive img-circle']);?>
                    </div>
                    <?php } ?>
                    <?php the_content(); ?>
                    <a href="#"><?php the_field('customer_name'); ?></a>
                </div>
              </div>
              <?php $count++; endwhile; wp_reset_postdata();?>
            </div>
            <!-- Left and right controls -->
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<?php } ?>
<footer id="contact_us">
  <div class="container">
    <div class="email_main_section">
      <div class="row">
        <div class="col-sm-70">
          <!--<div class="subscription_mail">
            <p>Inbox inspiration to help you achieve your goals:</p>
            <div class="input-group">
              <input type="text" class="form-control" id="exampleInputAmount" placeholder="Please enter your email address...">
              <div class="input-group-addon color-1">
                <button class="btns btn-1c">Send</button>
              </div>
            </div>
          </div>-->
          <?php 
           // if(is_active_sidebar('footer-email-subscription'))
                //dynamic_sidebar('footer-email-subscription');
          ?>
		  <div class="subscribe"><?php echo do_shortcode('[mc4wp_form id="516"]');?></div>
        </div>
        <div class="col-sm-30">
          <!--<div class="home_social">
            <p>We’re social!</p>
            <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a> <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a> <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a> </div>
        </div>-->
        <?php 
            if(is_active_sidebar('footer-social'))
                dynamic_sidebar('footer-social');
          ?>
      </div>
    </div>
  </div>
  </div>
  
  <div class="footer_bottom">
    <div class="container">
      <div class="row">
        <div class="col-sm-40">
          <!--<div class="footer_left_part">
            <p class="font_size_12">114 Pall mall, Chorley, PR7 2LB</p>
            <p>Vat Number: #######</p>
            <p> Diets 2 Go 2017.</p>
          </div>-->
          <?php 
            if(is_active_sidebar('lower-footer-left'))
                dynamic_sidebar('lower-footer-left');
          ?>
        </div>
		<div class="col-sm-20"><div class="paypallogo"><img src="<?php echo get_template_directory_uri();?>/paypal.png" alt="Powered by Paypal" title="Powered by Paypal" /></div></div>
        <div class="col-sm-40">
          <!--<div class="footer_right_part">
            <p>Email: info@diets2go.co.uk</p>
            <p>Phone number: 01234 56789</p>
          </div>-->
          <?php 
            if(is_active_sidebar('lower-footer-right'))
                dynamic_sidebar('lower-footer-right');
          ?>
        </div>
      </div>
    </div>
  </div>
</footer>
<a id="back-to-top" href="#" class="back-to-top" role="button" data-toggle="tooltip" data-placement="left"><i class="fa fa-long-arrow-up" aria-hidden="true"></i></a>
<!--footer part end-->
<?php wp_footer();?>
<div class="footer_copyright">
<div class="container">
<div class="row">
 <div class="col-sm-50">
  <div class="privacy-policy">
  <a href="<?php echo site_url();?>/privacy-policy">Privacy Policy</a>
	<a href="<?php echo site_url();?>/cookie-policy">Cookie Policy</a>
  </div></div>
        <div class="col-sm-50">
  <div class="footer_copyright_ed">
    <a href="https://www.embryodigital.co.uk" target="_blank">Cooked up and served by Embryo Digital</a>
  </div>
  </div>
 
  </div>
  </div>
  </div>
</body>
</html>