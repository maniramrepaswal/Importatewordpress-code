<?php
/**
 *  The template for displaying the front page.
 *
 *  @package WordPress
 *  @subpackage illdy
 */


get_header();


if ( get_option( 'show_on_front' ) == 'posts' ) : 
    	
    $args = array("category_name" => "home-page");
    $query = new WP_Query($args);
    if($query->have_posts()):
        $post_count = 1;
        while($query->have_posts()):
            $query->the_post();
    /*
    logic for featured images
    if post_count - odd, featured image in right, 
    else featured image in left.
    */
    if(has_post_thumbnail()){
        $style = "";
        $attachement = get_the_post_thumbnail_url(get_the_ID(), 'full');
        $style = "background: url('".$attachement."');";
        if($post_count % 2 == 0){
            $style .= "background-position: left 50px; background-repeat: no-repeat";
        }
        else{
            $style .= "background-position: right 50px; background-repeat: no-repeat";
        }
    }
?>
            <section id="home_<?php echo $post->post_name;?>_section" class="home<?php echo $post_count; ?>" style="<?php echo $style;?>">
               <?php //echo get_the_post_thumbnail(); ?>
                <div class="container">
                    <div class="row">
                        <div class="col-sm-100">
                            <div class="home_<?php echo $post->post_name;?> home_section_posts">
                                <h2 class="post_title"><?php the_title();?></h2>
                                <?php the_content();?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>   
<?php                               
        $post_count++;
        endwhile;
        wp_reset_postdata();
    endif;


    //having meal section
    if(is_active_sidebar('front-page-meal-sidebar')):
?>
    
    <section id="having_meal">
        <div class="container">
            <?php dynamic_sidebar('front-page-meal-sidebar');?>
        </div>
    </section>
    
<?php                   
    endif;


    //delivery process
    if(is_active_sidebar('front-page-delivery-process')):

?>
    <section id="delivery_process">
        <div class="container">
            <div class="container">
                <?php dynamic_sidebar('front-page-delivery-process');?>
            </div>
        </div>
    </section>

<?php
    endif;


    //get from you section
    if(is_active_sidebar('front-page-get-from-you')):
?>
    
    <section id="get_from_you">
        <div class="container">
           <div class="row">
               <?php dynamic_sidebar('front-page-get-from-you');?>
           </div>
        </div>
    </section>
    
<?php                   
    endif;


    //takes your fancy section
    if(is_active_sidebar('front-page-takes-your-fancy')):
?>

    <section id="takes_your_fancy">
        <div class="container">
            <?php dynamic_sidebar('front-page-takes-your-fancy');?>
            
            <div class="slider-products-part">
            	<div class="row">
            		<div class="col-md-100">
            			<div class="slider-products-row buttoncenter">
            				<div class="slider8">
            				    <?php 
            				        $args = array("post_type" => "product","post__not_in"=>array('264'));
            				        $query = new WP_Query($args);
            				        while($query->have_posts()):
            				            $query->the_post();
            				    ?>
            					<div class="slide">
            						<div class="slide-box-part">
            						    <?php if ( has_post_thumbnail() ) : ?>
                                            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                                                <?php the_post_thumbnail('full', ['class' => 'img-responsive','title' => get_the_title(), 'alt' => get_the_title()]); ?>
                                            </a>
                                        <?php endif; ?>
            							<div class="slide_categroy_part">
            								<h2><?php the_title();?> </h2>
            								<?php //the_excerpt(); ?>
											<?php echo apply_filters( 'woocommerce_short_description', $post->post_excerpt ) ?>
            							</div>
            						</div>
            					</div>
            					<?php endwhile; wp_reset_postdata();?>
            					
            				</div>
            				<div class="text-center color-1 start_your_journey"> <a href="<?php echo site_url();?>/order-now-about/" class="btns btn-1c">Get Started</a> </div>
            			</div>
            		</div>
            	</div>
            </div>
            
        </div>  
    </section>
    
<?php
    endif;
    
    
?>

    
    
   
    
    
    
<?php
    //endif;
          
else :

	if ( have_posts() ) :
		while ( have_posts() ) : the_post();
			$static_page_content = get_the_content();
			if ( '' != $static_page_content ) : ?>
				<section class="front-page-section" id="static-page-content">
					<div class="section-content">
						<?php echo $static_page_content; ?>
					</div>
				</section>
			<?php endif;
		endwhile;
	endif;

	illdy_sections();

endif;

get_footer(); ?>
