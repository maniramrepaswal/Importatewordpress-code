<?php
    add_theme_support( 'custom-logo', array(
		'height'      => 174,
		'width'      => 174,
		'flex-height' => false,
		'flex-width'  => false,
    ) );

    function add_css_js(){
        wp_enqueue_style('modified-bootstrap-css', get_stylesheet_directory_uri()."/css/bootstrap.css");
        wp_enqueue_style('font-awesome', get_template_directory_uri()."/layout/css/font-awesome.min.css");
        wp_enqueue_style('bxslider-css', get_stylesheet_directory_uri()."/css/jquery.bxslider.css");
        wp_enqueue_style('child-main-css', get_stylesheet_directory_uri()."/style.css", array());
        wp_enqueue_style('resposive', get_stylesheet_directory_uri()."/css/resposive.css", array("illdy-style"));
        
        wp_enqueue_script('bootstrap-js', get_template_directory_uri()."/layout/js/bootstrap/bootstrap.min.js", array('jquery'), '', true);
        wp_enqueue_script('bxslider-js', get_stylesheet_directory_uri()."/js/jquery.bxslider.js", array('jquery'), '', true);
        wp_enqueue_script('scripet-js', get_stylesheet_directory_uri()."/js/scripet.js", array('jquery'), '', true);
        wp_enqueue_script('scripet-new-js', get_stylesheet_directory_uri()."/js/scripet-new.js", array('jquery'), '', true);
        wp_enqueue_script('custom-js', get_stylesheet_directory_uri()."/js/custom.js", array('jquery'), '', true);
    }

    add_action("wp_enqueue_scripts", "add_css_js");

    if ( ! function_exists( 'illdy_child_widgets' ) ) {
        add_action( 'widgets_init', 'illdy_child_widgets' );
        
        function illdy_child_widgets() {

            // Front Page Header Sidebar
            register_sidebar( array(
                'name'          => __( 'Front Page Header Sidebar', 'illdy' ),
                'id'            => 'front-header-sidebar',
                'description'   => __( 'Widget added here goes in the big circle in header image.', 'illdy' ),
                'before_widget' => '<div id="%1$s" class="widget %2$s">',
                'after_widget'  => '</div>',
                'before_title'  => '<div class="widget-title">',
                'after_title'   => '</div>',
            ) );
            
            // Front Page Meal Sidebar
            register_sidebar( array(
                'name'          => __( 'Front Page Meal Sidebar', 'illdy' ),
                'id'            => 'front-page-meal-sidebar',
                'description'   => __( 'Widget added here goes in the having a meal section on home page.', 'illdy' ),
                'before_widget' => '<div id="%1$s" class="widget %2$s">',
                'after_widget'  => '</div>',
                'before_title'  => '<div class="widget-title">',
                'after_title'   => '</div>',
            ) );
            
            // Front Page Delivery Process Sidebar
            register_sidebar( array(
                'name'          => __( 'Front Page Delivery Process Sidebar', 'illdy' ),
                'id'            => 'front-page-delivery-process',
                'description'   => __( 'Widget added here goes in the how it works section on home page.', 'illdy' ),
                'before_widget' => '<div id="%1$s" class="widget %2$s">',
                'after_widget'  => '</div>',
                'before_title'  => '<div class="widget-title">',
                'after_title'   => '</div>',
            ) );
            
            // Front Page Get From You Sidebar
            register_sidebar( array(
                'name'          => __( 'Front Page Get From You Sidebar', 'illdy' ),
                'id'            => 'front-page-get-from-you',
                'description'   => __( 'Widget added here goes in the get from you section on home page.', 'illdy' ),
                'before_widget' => '<div id="%1$s" class="widget %2$s">',
                'after_widget'  => '</div>',
                'before_title'  => '<div class="widget-title">',
                'after_title'   => '</div>',
            ) );
            
            // Front Page Takes Your Fancy Sidebar
            register_sidebar( array(
                'name'          => __( 'Front Page Takes Your Fancy Sidebar', 'illdy' ),
                'id'            => 'front-page-takes-your-fancy',
                'description'   => __( 'Widget added here goes in the takes your fancy section on home page.', 'illdy' ),
                'before_widget' => '<div id="%1$s" class="widget %2$s">',
                'after_widget'  => '</div>',
                'before_title'  => '<div class="widget-title">',
                'after_title'   => '</div>',
            ) );
            
            /*// Testimonial Sidebar
            register_sidebar( array(
                'name'          => __( 'Testimonial Sidebar', 'illdy' ),
                'id'            => 'testimonial-sidebar',
                'description'   => __( 'Widget added here goes in the testimonials section.', 'illdy' ),
                'before_widget' => '<div id="%1$s" class="widget %2$s">',
                'after_widget'  => '</div>',
                'before_title'  => '<div class="widget-title">',
                'after_title'   => '</div>',
            ) );*/
            
            //Footer Subscription Widget
            register_sidebar( array(
                'name'          => __( 'Footer Email Subscription', 'illdy' ),
                'id'            => 'footer-email-subscription',
                'description'   => __( 'Widget added here goes in the footer email subscription section.', 'illdy' ),
                'before_widget' => '<div id="%1$s" class="widget %2$s subscription_mail">',
                'after_widget'  => '</div>',
                'before_title'  => '<div class="widget-title">',
                'after_title'   => '</div>',
            ) );
            
            //Footer Social Widget
            register_sidebar( array(
                'name'          => __( 'Footer Social', 'illdy' ),
                'id'            => 'footer-social',
                'description'   => __( 'Widget added here goes in the footer social section.', 'illdy' ),
                'before_widget' => '<div id="%1$s" class="widget %2$s home_social">',
                'after_widget'  => '</div>',
                'before_title'  => '<div class="widget-title">',
                'after_title'   => '</div>',
            ) );
            
            //Lower Footer Left Widget
            register_sidebar( array(
                'name'          => __( 'Lower Footer Left', 'illdy' ),
                'id'            => 'lower-footer-left',
                'description'   => __( 'Widget added here goes in the left lower footer section.', 'illdy' ),
                'before_widget' => '<div id="%1$s" class="widget %2$s footer_left_part">',
                'after_widget'  => '</div>',
                'before_title'  => '<div class="widget-title">',
                'after_title'   => '</div>',
            ) );
            
            //Lower Footer Right Widget
            register_sidebar( array(
                'name'          => __( 'Lower Footer Right', 'illdy' ),
                'id'            => 'lower-footer-right',
                'description'   => __( 'Widget added here goes in the right lower footer section.', 'illdy' ),
                'before_widget' => '<div id="%1$s" class="widget %2$s footer_right_part">',
                'after_widget'  => '</div>',
                'before_title'  => '<div class="widget-title">',
                'after_title'   => '</div>',
            ) );
        }
    }
    if(!function_exists('illdy_child_menu_setup')){
        add_action( 'after_setup_theme', 'illdy_child_menu_setup' );
        function illdy_child_menu_setup(){
            
            // Register Nav Menus
		    register_nav_menus( array(
			    'primary-menu-inner' => __( 'Primary Menu Inner', 'illdy-child' ),
		    ) );
        }
    }
    if(!function_exists('unregister_illdy_widgets')){
        add_action('widgets_init', 'unregister_illdy_widgets', 11);
        
        function unregister_illdy_widgets(){
            unregister_sidebar('footer-sidebar-1');
            unregister_sidebar('footer-sidebar-2');
            unregister_sidebar('footer-sidebar-3');
            unregister_sidebar('footer-sidebar-4');
            unregister_sidebar('front-page-about-sidebar');
            unregister_sidebar('front-page-projects-sidebar');
            unregister_sidebar('front-page-services-sidebar');
            unregister_sidebar('front-page-counter-sidebar');
            unregister_sidebar('front-page-team-sidebar');
            unregister_sidebar('front-page-full-width-sidebar');
            unregister_sidebar('front-page-testimonials-sidebar');
            unregister_sidebar('front-page-testimonials-sidebar');
            unregister_sidebar('front-page-testimonials-sidebar');
            unregister_sidebar('blog-sidebar');
            unregister_sidebar('page-sidebar');
            unregister_sidebar('woocommerce-sidebar');
        }
    }

    add_filter('wp_nav_menu_items', 'add_login_logout_link', 10, 2);
    function add_login_logout_link($items, $args) {
        ob_start();
        wp_loginout();
        $loginoutlink = ob_get_contents();
        ob_end_clean();
        //$items .= '<li>'. $loginoutlink .'</li>';
		if(is_user_logged_in()){
			$cls="";
			if(is_page('156')){
				$cls="current-menu-item page_item page-item-156 current_page_item";
			}
			$items .= '<li class="'.$cls.'"><a href="'.site_url().'/my-account/">My Account</a></li>';
		}
		else {
 $items .= '<li><a href="'. wp_login_url(get_permalink()) .'">Login</a></li>';
 }
        return $items;
    }
	
	
	
	
/************ order now plugin ************/


$oN_cat_ids = array();
    require_once(ABSPATH . 'wp-config.php'); 
    require_once(ABSPATH . 'wp-includes/wp-db.php'); 
    require_once(ABSPATH . 'wp-admin/includes/taxonomy.php');

function oN_cat_init(){   
    $oN_cat = array(
        array('cat_name' => 'Weight Loss', 'slug' => 'oN-weight-loss'),
        array('cat_name' => 'Balanced', 'slug' => 'oN-balanced'),
        array('cat_name' => 'Shredding', 'slug' => 'oN-shredding'),
        array('cat_name' => 'Lean Mass', 'slug' => 'oN-lean-mass'),
        array('cat_name' => 'Extreme Mass', 'slug' => 'oN-extreme-mass'),
    );
    if(oN_insert_cat($oN_cat))  return true;
}

function oN_insert_cat($args){
    $x = 1;
    foreach($args as $arg){
        $oN_cat_id	=	wp_insert_term(
            $arg["cat_name"], 
            'product_cat', 
            array( 'slug'	=>	$arg["slug"] )
        );
        if ( is_wp_error( $oN_cat_id ) ) {
            $term_id = isset($oN_cat_id->error_data['term_exists']) ? $oN_cat_id->error_data['term_exists'] : null;
        } else {
            $term_id = $oN_cat_id['term_id'];
        }
        
        if(isset($oN_cat_id["term_id"]) == false)   $x = 0;
        
    }
    return ($x == 1) ? true : false;
    
}

/* Function to create category from order now plugin start */
add_action("init",'oN_create_category_goals');
function oN_create_category_goals(){
	if(isset($_POST["add_dietgoalsSubmit"])){
		require_once(ABSPATH . 'wp-config.php'); 
		require_once(ABSPATH . 'wp-includes/wp-db.php'); 
		require_once(ABSPATH . 'wp-admin/includes/taxonomy.php');
		
		$cat_name		=	$_POST["newcat1"];
		$cat_slug		=	'oN-'.str_replace(' ', '-', strtolower($cat_name));
		wp_insert_term($cat_name, 'product_cat', array('slug'=>$cat_slug));
	}
}
/* Function to create category from order now plugin end */

function cat_add_success(){ echo 'New Diet Goal Added';    }
function cat_add_failure(){ echo 'Diet Goal Not Added';    }


add_action( 'woocommerce_before_calculate_totals', 'add_custom_item_price', 99 );
function add_custom_item_price( $cart_object ) {
	foreach ( $cart_object->get_cart() as $item_values ) {
		$item_id = $item_values['data']->id; // Product ID
		$cart_item_key = $item_values['key']; // Product ID
		$original_price = $item_values['data']->price; // Product original price
		// $price1		=	$_SESSION['price1']; 
		$price1		=	$_COOKIE['price1'];
		// $price1		=	782;
		// $new_name	=	$_SESSION['new_name'];
		$new_name	=	$_COOKIE['new_name'];
		// $new_name	=	"2 Meals per day for 5 Dayss";
		$item_values['data']->set_price($price1);
		// print_r($_SESSION);
		// print_r($_COOKIE);
		// echo $price1." - ".$new_name; 
		// echo "<br/>COOKIE".$_COOKIE['price1']." - ".$_COOKIE['new_name']; 
		if( method_exists( $item_values['data'], 'set_name' ) )
			$item_values['data']->set_name( $new_name );
		else
			$item_values['data']->post->post_title = $new_name;
	}
}

//add_action( 'woocommerce_cart_calculate_fees', 'woo_add_cart_fee' );
function woo_add_cart_fee() {
	global $woocommerce;
 	$shipping_rate = $_COOKIE['shipping_rate'];
 	$added_code  = $_COOKIE['added_code'];
 	$woocommerce->cart->add_fee( __('Shipping Cost for Post Code '.$added_code, 'woocommerce'), $shipping_rate );
}



add_action("wp_ajax_total_data_save_function","total_data_save_function");
function total_data_save_function(){
	$data	=	json_decode(str_replace("\\","",sanitize_text_field($_POST['data'])));
	// pr($data);
	$output			=	0;
	$custom_data	=	array();
	$custom_data	=	$data;
	// pr($custom_data);
	$stp2_array		=	explode(":",$custom_data->stp2_val);
	$stp2_meal		=	$stp2_array[0];
	$stp2_days		=	$stp2_array[1];
	$stp2_val		=	(int)$stp2_array[2];
	$stp4_times		=	1;
	/* $stp4_pp_price	=	0;
	$stp4_pj_qty	=	0;
	$stp4_pj_price	=	0; */
	/* if(isset($custom_data->stp4_pp_qty) && !empty($custom_data->stp4_pp_qty))
		$stp4_pp_price	=	(int)$custom_data->stp4_pp_price*(int)$custom_data->stp4_pp_qty;
	if(isset($custom_data->stp4_pj_gp) && !empty($custom_data->stp4_pj_gp))
		$stp4_pj_qty	+=	(int)$custom_data->stp4_pj_gp;
	if(isset($custom_data->stp4_pj_br) && !empty($custom_data->stp4_pj_br))
		$stp4_pj_qty	+=	(int)$custom_data->stp4_pj_br;
	if(isset($custom_data->stp4_pj_dp) && !empty($custom_data->stp4_pj_dp))
		$stp4_pj_qty	+=	(int)$custom_data->stp4_pj_dp;
	if(isset($custom_data->stp4_pj_t) && !empty($custom_data->stp4_pj_t))
		$stp4_pj_qty	+=	(int)$custom_data->stp4_pj_t;
	if(isset($custom_data->step6_array->weeks_count) && !empty($custom_data->step6_array->weeks_count))
		$week_count	=	(int)$custom_data->step6_array->weeks_count;
	if($stp4_pj_qty != 0)
		$stp4_pj_price	=	(int)$custom_data->stp4_pj_price*(int)$stp4_pj_qty;
	if(isset($custom_data->stp4_times) && !empty($custom_data->stp4_times))
		$stp4_times		=	(int)$custom_data->stp4_times;
	$new_price			=	($stp2_val + $stp4_pp_price + $stp4_pj_price) * $stp4_times;
	 */
	$stp4_price		=	0;
	foreach($custom_data->stp4_data as $key=>$val){
		$stp4_price	+=	(float)$val->total;
	}
	if(isset($custom_data->step6_array->weeks_count) && !empty($custom_data->step6_array->weeks_count))
		$week_count	=	(int)$custom_data->step6_array->weeks_count;
	if(isset($custom_data->stp4_times) && !empty($custom_data->stp4_times))
		$stp4_times		=	(int)$custom_data->stp4_times;
	
	//$new_price			=	($stp2_val + $stp4_price) * $stp4_times;
	$new_price			=	($stp2_val + $stp4_price);
	
	global $wpdb, $table_name;
	$postcodess			=	$wpdb->get_row("SELECT field_value from $table_name where field_type='postcodes'",ARRAY_A);
	$postcodes			=	json_decode($postcodess['field_value']);
	
	$added_code			=	$custom_data->step6_array->add_postcode;
	$extra_price		=	0;
	$finalcodeval = $added_code;
	/* managing postcode RK*/
	$added_code = str_replace(" ","",$added_code);
	$added_code = substr($added_code,0,-3);
	
	/*foreach($postcodes as $k=>$v){
		if(strtolower($added_code) == strtolower($k)){
			$extra_price	=	(float)$v;
			break;
		}else{
			if($k == 'Other'){ $extra_price = (float)$v; }
		}
	}*/
	
	foreach($postcodes as $k=>$v){
		if(strtolower($added_code) == strtolower($k)){
			$shiparr=explode("--",$v);
			if($stp4_times==2){
				$extra_price	=	(float)$shiparr[1];
			}else{
				$extra_price	=	(float)$shiparr[0];
			}
			break;
		}else{
			if($k == 'Other'){ 
                               $shiparr=explode("--",$v);
				if($stp4_times==2){
					$extra_price	=	(float)$shiparr[1];
				}else{
					$extra_price	=	(float)$shiparr[0];
				}
			}
		}
	}
	
	//$extra_price = (float)($extra_price * $stp4_times);
	
	// $new_price			=	$new_price*$week_count;
	$price1 			= 	$new_price + $extra_price;
	
	$new_name			=	$stp2_meal." Meals per day for ".$stp2_days." Days";
	/* Custom Data Save in Table Start */
	/* new table name - diet_oN_order_data */
	global $current_user;
	$tb_name			=	$wpdb->prefix . 'oN_order_data';
	$user_id			=	get_current_user_id();
	$order_data			=	json_encode($custom_data);
	$created			=	date('Y-m-d H:i:s');
	$tb_data			=	array(
								'user_id'		=>	$user_id,
								'order_data'	=>	$order_data,
								'created_date'	=>	$created,
							);
	$success			=	$wpdb->insert($tb_name,$tb_data);
	$lastid 			= 	$wpdb->insert_id;
	setcookie('lastid',$lastid,time()+3000,"/");
	/* Custom Data Save in Table End */
	global $woocommerce;
	$woocommerce->cart->empty_cart();
	$product_id			=	264;
	$quantity			=	$week_count;
	$woocommerce->cart->add_to_cart( $product_id, $quantity);
	// $_SESSION['price1']		=	$price1;
	// $_SESSION['new_name']	=	$new_name;
	setcookie('price1',$price1,time()+3000,"/");
	setcookie('new_name',$new_name,time()+3000,"/");
	setcookie('added_code',$finalcodeval,time()+3000,"/");
 	setcookie('shipping_rate',$extra_price,time()+3000,"/");
	$output 			= 	1;
	echo $output;
	// echo do_shortcode('[woocommerce_checkout]');
	wp_die();
}
add_action('woocommerce_checkout_update_order_meta', 'customise_checkout_field_update_order_meta');
 
function customise_checkout_field_update_order_meta($order_id){
	if (!empty($_COOKIE['lastid'])) {
		update_post_meta($order_id, 'last_id', sanitize_text_field($_COOKIE['lastid']));
		setcookie('lastid','',time()+3000,"/");
	}
}



/************ WOOCOMMERCE ************/

function oN_woo_my_account_order() {
	$myorder = array(
		'dashboard' => __( 'Dashboard', 'woocommerce' ),
		'update-weight-goal'       => __( 'Update Weight / Goal', 'woocommerce' ),
		'orders'             => __( 'Orders', 'woocommerce' ),
		'edit-address'       => __( 'Addresses', 'woocommerce' ),
		'payment-methods'    => __( 'Payment Methods', 'woocommerce' ),
        'edit-account'    => __( 'Account details', 'woocommerce' ),
		/*'return-credit'    => __( 'Returns Credit', 'woocommerce' ),*/
	);
	return $myorder;
}
add_filter ( 'woocommerce_account_menu_items', 'oN_woo_my_account_order' );

add_action( 'woocommerce_account_update-weight-goal_endpoint', 'oN_update_weight_goal_content' );
add_action( 'woocommerce_account_return-credit_endpoint', 'oN_return_credit_content');
/**
 * Custom Endpoint content
 */
function oN_update_weight_goal_content() {
    wc_get_template('myaccount/update-weight-goal.php');
}
function oN_return_credit_content(){
    wc_get_template('myaccount/return-credit.php');
}


/************ WOOCOMMECRE MYACCOUNT ************/
function fetch_myaccount_page_name(){
    $pagename = $_SERVER["REQUEST_URI"];
    if(strpos($pagename, "?") !== false){
        $temp = explode("?", $pagename);
        $pagename = $temp[0];
    }
    $pagename = strrev($pagename);
    if(str_split($pagename)[0] == "/")
        return (is_numeric(strtoupper(strrev(substr($pagename, 1, (nth_position($pagename, "/", 2))-1))))) ? "" : stripSplChars((strtoupper(strrev(substr($pagename, 1, (nth_position($pagename, "/", 2))-1))))) ;
    else
        return (is_numeric(strtoupper(strrev(substr($pagename, 0, (nth_position($pagename, "/", 2))-1))))) ? "" : stripSplChars((strtoupper(strrev(substr($pagename, 0, (nth_position($pagename, "/", 2))-1))))) ;
    
}
function nth_position($str, $letter, $n, $offset = 0){
    $str_arr = str_split($str);
    $letter_size = array_count_values(str_split(substr($str, $offset)));
    if( !isset($letter_size[$letter])){
        trigger_error('letter "' . $letter . '" does not exist in ' . $str . ' after ' . $offset . '. position', E_USER_WARNING);
        return false;
    } else if($letter_size[$letter] < $n) {
        trigger_error('letter "' . $letter . '" does not exist ' . $n .' times in ' . $str . ' after ' . $offset . '. position', E_USER_WARNING);
        return false;
    }
    for($i = $offset, $x = 0, $count = (count($str_arr) - $offset); $i < $count, $x != $n; $i++){
        if($str_arr[$i] == $letter){
            $x++;
        }
    }
    return $i - 1;
}

function stripSplChars($rawInput){
    return preg_replace('/-/', ' ', $rawInput);
}

add_action( 'init', function(){
    add_rewrite_endpoint( 'update-weight-goal', EP_PAGES );
    add_rewrite_endpoint( 'return-credit', EP_PAGES );
} );

add_action( 'template_redirect', function(){
    if( !function_exists( 'wc_get_page_id' ) ){
        return;
    }

    if( is_page( wc_get_page_id( "myaccount" ) ) && ! is_user_logged_in() ){
        wp_redirect( site_url( 'login/' ) );
    }
} );

// Blog Function Code
	function post_type_discog1() {

register_post_type('blog',
    array(
    'labels' => array(
            'name' => __( 'All Blog' ),
            'singular_name' => __( 'Blog' ),
            'add_new' => __( 'Add New' ),
            'add_new_item' => __( 'Add New Blog' ),
            'edit' => __( 'Edit' ),
            'edit_item' => __( 'Edit Blog' ),
            'new_item' => __( 'New Blog' ),
            'view' => __( 'View Blog' ),
            'view_item' => __( 'View Blog' ),
            'search_items' => __( 'Search Blog' ),
            'not_found' => __( 'No Blog found' ),
            'not_found_in_trash' => __( 'No Blog found in Trash' ),
            'parent' => __( 'Parent Blog' ),
        ),
  'public' => true,
  'show_ui' => true,
        'exclude_from_search' => true,
        'hierarchical' => false,
        'supports' => array( 'title', 'thumbnail','editor','custom-fields', 'author',  ),
        'query_var' => true
        )
  );
}
add_action('init', 'post_type_discog1');

add_action( 'init', 'create_discog1_taxonomies', 0 );

function create_discog1_taxonomies()
{
  // Add new taxonomy, make it hierarchical (like categories)
  $labels = array(
    'name' => _x( 'Categories', 'taxonomy general name' ),
    'singular_name' => _x( 'blog_categories', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Categories' ),
    'popular_items' => __( 'Popular Categories' ),
    'all_items' => __( 'All Categories' ),
    'parent_item' => __( 'Parent Categories' ),
    'parent_item_colon' => __( 'Parent Categories:' ),
    'edit_item' => __( 'Edit Categories' ),
    'update_item' => __( 'Update Categories' ),
    'add_new_item' => __( 'Add New Categories' ),
    'new_item_name' => __( 'New Categories Name' ),
  );
  register_taxonomy('blog_categories',array('blog'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'Categories' ),
  ));
}

function include_template_function1( $template_path ) {
    if ( get_post_type() == 'blog' ) {
        if ( is_single() ) {
	
            // checks if the file exists in the theme first,
            // otherwise serve the file from the plugin
            if ( $theme_file = locate_template( array ( 'template-single-blog.php' ) ) ) {
                $template_path = $theme_file;
            } else {
                $template_path = plugin_dir_path( __FILE__ ) . '/template-single-blog.php';
            }
        } else {
             
        }
    }
  return $template_path;
}
add_filter( 'template_include', 'include_template_function1', 1 );

/* Reorder function */
add_action("init","oN_reorder");
function oN_reorder(){
	if(isset($_POST['reorder'])){
		global $woocommerce;
		$p_name			=	sanitize_text_field($_POST['p_name']);
		$p_price		=	sanitize_text_field($_POST['p_price']);
		$p_qty			=	sanitize_text_field($_POST['p_qty']);
		$last_id		=	sanitize_text_field($_POST['last_id']);
		setcookie('lastid',$last_id,time()+3000,"/");
		$woocommerce->cart->empty_cart();
		$product_id	=	264;
		$woocommerce->cart->add_to_cart( $product_id, $p_qty);
		setcookie('price1',$p_price,time()+3000,"/");
		setcookie('new_name',$p_name,time()+3000,"/");
		$checkout	=	site_url().'/checkout';
		wp_redirect($checkout);
		exit;
	}
}
