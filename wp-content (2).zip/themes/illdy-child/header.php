<?php
    
    $logo_id = get_theme_mod( 'custom_logo' );
    $logo_image = wp_get_attachment_image_src( $logo_id, 'full' );
    $text_logo = get_theme_mod( 'illdy_text_logo', __( 'Illdy', 'illdy' ) );
    //$jumbotron_general_image = get_theme_mod( 'illdy_jumbotron_general_image', esc_url( get_template_directory_uri() . '/layout/images/front-page/front-page-header.png' ) );
    $jumbotron_single_image = get_theme_mod( 'illdy_jumbotron_enable_featured_image', false );
    $jumbotron_parallax_enable = get_theme_mod( 'illdy_jumbotron_enable_parallax_effect', true );
    $preloader_enable = get_theme_mod( 'illdy_preloader_enable', 0 );
    $style = '';

    if ( get_option( 'show_on_front' ) == 'page' && is_front_page() ) {
        $style = 'background-image: url(' . get_header_image() . '); background-position: center center';
    } else if ( ( is_single() || is_page() ) && $jumbotron_single_image == true ) {

        global $post;
        if ( has_post_thumbnail( $post->ID ) ) {
            $style = 'background-image: url(' . esc_url( get_the_post_thumbnail_url( $post->ID, 'full' ) ) . ');';
        }
    } else {
        $style = 'background-image: url(' . get_header_image() . ');background-position: center center';
    }

    // append the parallax effect
    /*if ( $jumbotron_parallax_enable == true ) {
        $style .= 'background-attachment: fixed;';        
    }

    if ( ( is_single() || is_page() || is_archive() ) && get_theme_mod( 'illdy_archive_page_background_stretch' ) == 2 ) {
        $style .= 'background-size:contain;background-repeat:no-repeat;';
    }*/

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<!-- Hotjar Tracking Code for https://www.diets2go.co.uk/ -->
<script>
    /*(function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:818971,hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');*/
</script>
<meta charset="<?php bloginfo( 'charset' ); ?>" >
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head();?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-113008165-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-113008165-1');
</script>

</head>
<body <?php body_class(); ?>>

<?php if ( $preloader_enable == 1 ): ?>
	<div class="pace-overlay"></div>
<?php endif; ?>

<!--header start-->
<header>
  <div class="container">
    <div class="header-part">
      <div class="row">
        <!--logo part start-->
        <div class="col-sm-30">
          <div class="logo-part"> 
                          
                <?php if ( ! empty( $logo_image ) ) { ?>
                <?php echo '<a href="' . esc_url( home_url() ) . '"><img src="' . esc_url( $logo_image[0] ) . '" class="img-responsive" /></a>'; ?>
				<?php } else { ?>
				<?php if ( get_option( 'show_on_front' ) == 'page' ) { ?>
					<a href="<?php echo esc_url( home_url() ); ?>" title="<?php echo esc_attr( $text_logo ); ?>" class="header-logo"><?php echo esc_html( $text_logo ); ?></a>
        		<?php } else { // front-page option ?>
					<a href="<?php echo esc_url( home_url() ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" class="header-logo"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></a>
				<?php } ?>
				<?php } ?>              
              
            </div>
        </div>
        <!--logo part End-->
        <!--menu part start-->
        <div class="col-sm-70">
          <div class="menu-part">
            <nav class="navbar">
              <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <i class="fa fa-bars" aria-hidden="true"></i> </button>
                            
              <?php
                if(is_home() || is_front_page()){
                    $args = array(
                        "theme_location" => "primary-menu",
                        "container" => "div",
                        "container_class" => "collapse navbar-collapse",
                        "container_id" => "navbarSupportedContent"
                    );
                }
                else{
                    $args = array(
                        "theme_location" => "primary-menu-inner",
                        "container" => "div",
                        "container_class" => "collapse navbar-collapse",
                        "container_id" => "navbarSupportedContent"
                    );
                }
                    wp_nav_menu( $args );
                ?>
              
            </nav>
          </div>
        </div>
        <!--menu  End-->
      </div>
    </div>
  </div>
</header>
<!--header end-->
<!--slider section   start-->
<?php if ( is_home() || is_front_page() ) { ?>
<div class="banner-part">


  <div class="container">
    <div class="row">
      <div class="col-sm-100">
        <?php (is_active_sidebar('front-header-sidebar')) ? dynamic_sidebar('front-header-sidebar') : ''; ?>
      </div>
    </div>
  </div>
  <div style="z-index: -99; width: 100%; height: 100%">
  <iframe width="100%" height="720" src="https://www.youtube.com/embed/ejHS6VJSEhE" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen style="position:absolute;top:0;left:0;width:100%;height:100%;"></iframe>
</div>
</div>
<?php } ?>