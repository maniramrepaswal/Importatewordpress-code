<?php get_header();?>
<!--slider section   End-->
<section id="home_why_us_section">
  <div class="container">
    <div class="row">
      <div class="col-sm-100">
        <div class="home_why_us">
          <h2>Why Us</h2>
          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<br>
            When an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
        </div>
      </div>
    </div>
  </div>
</section>
<section id="home_service_section">
  <div class="container">
    <div class="row">
      <div class="col-sm-100">
        <div class="home_why_us home_services color-1">
          <h2>Service </h2>
          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<br>
            When an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
          <p>Check Our Bespoke Menu</p>
          <a href="menu-pricing.html" class="btns btn-1c">View Menu</a> </div>
      </div>
    </div>
  </div>
</section>
<section id="having_meal">
  <div class="container">
    <div class="section_headding_part">
      <h3>Having a meal you enjoy is important</h3>
      <p>Take your mind off meal preping with our delicious meals preped in advance and<br>
        delivered straight to your doorstep ready to be eaten hot or cold!</p>
    </div>
    <div class="row">
      <div class="col-md-30 col-sm-33">
        <div class="having_meal_box"> <img src="images/meal1.jpg" alt="" class="img-responsive" />
		</div>
		<div class="having_meal_boxs">
          <h4>simple</h4>
          <p>Treat your self to delicious meals cooked with the finest frsh ingriedients and crafted with care.</p>
        </div>
      </div>
      <div class="col-md-offset-5 col-md-30 col-sm-34">
        <div class="having_meal_box"> <img src="images/meal2.jpg" alt="" class="img-responsive" /></div>
		<div class="having_meal_boxs">
          <h4>delicious</h4>
          <p>Treat your self to delicious meals cooked with the finest frsh ingriedients and crafted with care.</p>
        </div>
      </div>
      <div class="col-md-offset-5 col-md-30 col-sm-33">
        <div class="having_meal_box"> <img src="images/meal3.jpg" alt="" class="img-responsive" /></div>
		<div class="having_meal_boxs">
          <h4>variety</h4>
          <p>Treat your self to delicious meals cooked with the finest frsh ingriedients and crafted with care.</p>
        </div>
      </div>
    </div>
  </div>
</section>



<section id="delivery_process">
  <div class="container">
    <div class="section_headding_part how_it_work">
      <h3>How It Works</h3>
    </div>
    <div class="row">
      <div class="col-md-30 col-sm-33">
        <div id="f1_container">
          <div id="f1_card" class="shadow">
            <div class="front face"> <img src="images/order-stap1.png" alt="" class="img-responsive" /> </div>
            <div class="back face center"> <img src="images/order-stap1-flip.png" alt="" class="img-responsive" /> </div>
          </div>
        </div>
		<div  class="having_meal_boxs">
		 <h4>You Order</h4>
          <p>Choose from a selection of delicious, clean & healthy meals.</p>
		  </div>
      </div>
      <div class="col-md-offset-5 col-md-30 col-sm-34">
        <div id="f1_container">
          <div id="f1_card" class="shadow">
            <div class="front face"> <img src="images/order-stap2.png" alt="" class="img-responsive" /> </div>
            <div class="back face center"> <img src="images/order-stap2-flip.png" alt="" class="img-responsive" /> </div>
          </div>
        </div>
		<div class="having_meal_boxs">
		   <h4>We Prepare</h4>
          <p>Our chefs freshly prepare and customise your meals according to your diet goals & macros.</p>
		</div>
      </div>
      <div class="col-md-offset-5 col-md-30 col-sm-33">
        <div id="f1_container" class="having_meal_boxs">
          <div id="f1_card" class="shadow">
            <div class="front face"> <img src="images/order-stap3.png" alt="" class="img-responsive" /> </div>
            <div class="back face center"> <img src="images/order-stap3-flip.png" alt="" class="img-responsive" /> </div>
          </div>
        </div>
		<div class="having_meal_boxs">
		   <h4>And Deliver!</h4>
          <p>Get your meals delivered to your home or office at a time that is convenient for you.</p>
		</div>
      </div>
    </div>
    <div class="text-center color-1 start_your_journey"> <a href="#" class="btns btn-1c">Start your journey</a> </div>
  </div>
</section>
<section id="get_from_you">
  <div class="container">
    <div class="row">
      <div class="col-sm-100">
        <div class="get_from_us_main">
          <h3>What yor get from us</h3>
          <ul>
            <li><i class="fa fa-dot-circle-o" aria-hidden="true"></i> Our meals consist of sugar free, health,<br>
              gluten free meals.</li>
            <li><i class="fa fa-dot-circle-o" aria-hidden="true"></i> Up to 60 combinations and 14 signature<br>
              meals.</li>
            <li><i class="fa fa-dot-circle-o" aria-hidden="true"></i> Freshness Guranteed.</li>
            <li><i class="fa fa-dot-circle-o" aria-hidden="true"></i> Taste & consistency provided.</li>
            <li><i class="fa fa-dot-circle-o" aria-hidden="true"></i> Save time and enjoy your time eating<br>
              what’s right.</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>








<style>
.category_slider_part { margin:50px 0;}


.active .start_your_journey { display:block !important}


</style>



	





<section id="takes_your_fancy">
  <div class="container">
    <div class="section_headding_part">
      <h3>So what takes your fancy?</h3>
    </div>
<div class="row">
      <div class="col-sm-100">
        <div class="fancy_section client_testimonial">
          <ul class="bxsliders">
            <li><img src="images/fancy1.jpg" alt="" class="img-responsive" /></li>
            <li><img src="images/fancy1.jpg" alt="" class="img-responsive" /></li>
            <li class="active"><img src="images/fancy1.jpg" alt="" class="img-responsive" /></li>
            <li><img src="images/fancy1.jpg" alt="" class="img-responsive" /></li>
            <li><img src="images/fancy1.jpg" alt="" class="img-responsive" /></li>
          </ul>
          <div class="text-center color-1 start_your_journey"> <a href="#" class="btns btn-1c">Get Started</a> </div>
        </div>
      </div>
    </div>
  </div>
</section>
<?php get_footer();?>