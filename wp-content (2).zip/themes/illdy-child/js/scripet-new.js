// JavaScript Document
if (screen.width >= 320 && screen.width <= 519 ) {
jQuery(document).ready(function($){
  $('.bxslider').bxSlider({
      slideWidth: 340,
    minSlides: 1,
    maxSlides: 1,
    moveSlides: 1,
    slideMargin: 20,
	auto: true,
  autoControls: true
  });
  var slider = $('.slider8').bxSlider({
    mode: 'horizontal',
    slideWidth: 340,
    minSlides: 1,
	 maxSlides: 1,
    moveSlides: 1,
    slideMargin: 2    
});
});
}else if (screen.width >= 520 && screen.width <= 767 ) {
jQuery(document).ready(function($){
  $('.bxslider').bxSlider({
      slideWidth: 270,
    minSlides: 2,
    maxSlides:2,
    moveSlides: 1,
    slideMargin: 20,
	auto: true,
  autoControls: true
  });
  var slider = $('.slider8').bxSlider({
    mode: 'horizontal',
    slideWidth: 500,
    minSlides: 2,
	 maxSlides: 2,
    moveSlides: 1,
    slideMargin: 2    
});
});
}else if (screen.width >= 768 && screen.width <= 1366 ) {
	jQuery(document).ready(function($){
  $('.bxslider').bxSlider({
    slideWidth: 370,
    minSlides: 3,
    maxSlides: 3,
    moveSlides: 1,
    slideMargin: 20,
	auto: true,
  autoControls: true
  });
  var slider = $('.slider8').bxSlider({
    mode: 'horizontal',
    slideWidth: 500,
    minSlides: 3,
	 maxSlides: 3,
    moveSlides: 1,
    slideMargin: 2,
    onSliderLoad: function () {
        $('.slider8>div:not(.bx-clone)').eq(1).addClass('active-slide');
    },
    onSlideAfter: function ($slideElement, oldIndex, newIndex) {
        $('.slide').removeClass('active-slide');
        $($slideElement).next().addClass('active-slide');        
    }
});
});

}else{
  jQuery(document).ready(function($){
$('.bxslider').bxSlider({
slideWidth: 370,
  minSlides: 3,
  maxSlides: 3,
  moveSlides: 1,
  slideMargin: 40,
  auto: true,
autoControls: true
});

var slider = jQuery('.slider8').bxSlider({
    mode: 'horizontal',
    slideWidth: 500,
    minSlides: 3,
	 maxSlides: 3,
    moveSlides: 1,
    slideMargin: 2,
    onSliderLoad: function () {
        $('.slider8>div:not(.bx-clone)').eq(1).addClass('active-slide');
    },
    onSlideAfter: function ($slideElement, oldIndex, newIndex) {
        $('.slide').removeClass('active-slide');
        $($slideElement).next().addClass('active-slide');        
    }
});
});
}
