// JavaScript Document
if (screen.width >= 320 && screen.width <= 519 ) {
jQuery(document).ready(function($){
  $('.bxslider').bxSlider({
      slideWidth: 340,
    minSlides: 1,
    maxSlides: 1,
    moveSlides: 1,
    slideMargin: 20,
	auto: true,
  autoControls: true
  });
});
}else if (screen.width >= 520 && screen.width <= 767 ) {
jQuery(document).ready(function($){
  $('.bxslider').bxSlider({
      slideWidth: 270,
    minSlides: 2,
    maxSlides:2,
    moveSlides: 1,
    slideMargin: 20,
	auto: true,
  autoControls: true
  });
});
}else if (screen.width >= 768 && screen.width <= 1366 ) {
	jQuery(document).ready(function($){
  $('.bxslider').bxSlider({
    slideWidth: 370,
    minSlides: 3,
    maxSlides: 3,
    moveSlides: 1,
    slideMargin: 20,
	auto: true,
  autoControls: true
  });
});

}else{
  jQuery(document).ready(function($){
$('.bxslider').bxSlider({
slideWidth: 370,
  minSlides: 3,
  maxSlides: 3,
  moveSlides: 1,
  slideMargin: 40,
  auto: true,
autoControls: true
});
});
}

if (screen.width >= 320 && screen.width <= 519 ) {
jQuery(document).ready(function($){
  $('.bxsliders').bxSlider({
      slideWidth: 340,
    minSlides: 1,
    maxSlides: 1,
    moveSlides: 1,
    slideMargin: 20,
	auto: true,
  autoControls: true
  });
});
}else if (screen.width >= 520 && screen.width <= 767 ) {
jQuery(document).ready(function($){
  $('.bxsliders').bxSlider({
      slideWidth: 270,
    minSlides: 2,
    maxSlides:2,
    moveSlides: 1,
    slideMargin: 20,
	auto: true,
  autoControls: true
  });
});
}else if (screen.width >= 768 && screen.width <= 1023 ) {
jQuery(document).ready(function($){
  $('.bxsliders').bxSlider({
    slideWidth: 340,
    minSlides: 2,
    maxSlides: 2,
    moveSlides: 1,
    slideMargin: 20,
	auto: true,
  autoControls: true
  });
});

}else{
  jQuery(document).ready(function($){
$('.bxsliders').bxSlider({
slideWidth: 365,
  minSlides: 3,
  maxSlides: 3,
  moveSlides: 1,
  slideMargin: 30,
  auto: true,
autoControls: true
});
});
}


jQuery('a[href*="#"]')
  // Remove links that don't actually link to anything
  .not('[href="#"]')
  .not('[href="#0"]')
  .click(function(event) {
    // On-page links
    if (
      location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') 
      && 
      location.hostname == this.hostname
    ) {
      // Figure out element to scroll to
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
      // Does a scroll target exist?
      if (target.length) {
        // Only prevent default if animation is actually gonna happen
        event.preventDefault();
        $('html, body').animate({
          scrollTop: target.offset().top
        }, 1000, function() {
          // Callback after animation
          // Must change focus!
          var $target = $(target);
          $target.focus();
          if ($target.is(":focus")) { // Checking if the target was focused
            return false;
          } else {
            $target.attr('tabindex','-1'); // Adding tabindex for elements not focusable
            $target.focus(); // Set focus again
          };
        });
      }
    }
  });
jQuery(document).ready(function($){
    $("#inquery_now_home").click(function(){
        $("#inquerymaindiv").toggle('show');
    });
	$("#inquery_now_home_new").click(function(){
        $(".inquerymaindiv_new").toggle('show');
    });
	 $(".close_inquery_old").click(function(){
        $("#inquerymaindiv").toggle('show');
    });
	 $(".close_inquery_new").click(function(){
        $(".inquerymaindiv_new").toggle('show');
    });
});
jQuery(document).ready(function($){
     $(window).scroll(function () {
            if ($(this).scrollTop() > 50) {
                $('#back-to-top').fadeIn();
            } else {
                $('#back-to-top').fadeOut();
            }
        });
        // scroll body to 0px on click
        $('#back-to-top').click(function () {
            $('#back-to-top').tooltip('hide');
            $('body,html').animate({
                scrollTop: 0
            }, 800);
            return false;
        });
        
        $('#back-to-top').tooltip('show');

});


//header scroll effects functions start
	jQuery(window).scroll(function($) {
			if (jQuery(document).scrollTop() > 150) {
			jQuery('header').addClass('shrink');
			}
			else {
			jQuery('header').removeClass('shrink'); }
			});
//header scroll effects functions end