<?php
/**
 *  The template for dispalying the page.
 *
 *  @package WordPress
 *  @subpackage illdy
 */
?>
<?php get_header(); ?>
<?php 
    if(has_post_thumbnail()){
        $style = "";
        $attachement = get_the_post_thumbnail_url(get_the_ID(), 'full');
        $style = 'background: url("'.$attachement.'") center center;';
        if(is_page('117'))
            $style .= "background-size: cover";
?>
<?php 
        if(is_page(67)){
            echo "<div class='banner-part min_height550 hadding-banner-text' style='".$style."'><h2>".get_field('banner_text')."</h2></div>";
        }
        else if(is_page( array(231, 233, 234, 235) ) )
            echo "<div class='banner-part' style='".$style."'>";
        
        /*for page name as heading in my-account page*/
        else if(is_page(156))
            echo "<div class='banner-part min_height550 hadding-banner-text' style='".$style."'>
            <h2>".fetch_myaccount_page_name()."</h2></div>";
        else{
            echo "<div class='banner-part min_height550' style='".$style."'></div>";
        }
    }
?>

<div class="container">
	<div class="row">
		<?php if ( is_active_sidebar( 'page-sidebar' ) ) { ?>
		    <div class="col-sm-8">
        <?php } else { ?>
			<div class="col-sm-100">
        <?php } ?>
			<section id="blog">
				<?php
				if ( have_posts() ) :
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/content', 'page' );
					endwhile;
				endif;
				?>
			</section><!--/#blog-->
		</div><!--/.col-sm-100 or .col-sm-8-->
		<?php if ( is_active_sidebar( 'page-sidebar' ) ) { ?>
			<div class="col-sm-4">
				<div id="sidebar">
					<?php dynamic_sidebar( 'page-sidebar' ); ?>
				</div>
			</div>
		<?php } ?>
	</div><!--/.row-->
</div><!--/.container-->
<?php echo (is_page( array(231, 233, 234, 235) )) ? "</div>" : ""; ?>
<?php get_footer(); ?>
