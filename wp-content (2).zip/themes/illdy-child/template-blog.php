<?php 
    /*
    Template Name: Blog
    */
    get_header();

   
?>
<?php 
    if(has_post_thumbnail()){
        $style = "";
        $attachement = get_the_post_thumbnail_url(get_the_ID(), 'full');
        $style = "background: url('".$attachement."') center center;";
        if(is_page('117'))
            $style .= "background-size: cover";
?>
<div class="banner-part min_height550" style="<?php echo $style;?>"></div>
<?php   }   ?>
<div class="container">
<div class="row">

 <section id="content" class="blog-categories-section-main">
    <div class="wrap-content blog-single">
	
    <?php
	if ( get_query_var('paged') ) $paged = get_query_var('paged');
if ( get_query_var('page') ) $paged = get_query_var('page');
   $query = new WP_Query(array( 'post_type' => 'blog' )); 
 //echo "Last SQL-Query: {$query->request}";

if ( $query->have_posts() ) : ?>
<?php while ( $query->have_posts() ) : $query->the_post(); 
//echo '<pre>';
//print_r($query);

?>
   
	<div class="col-sm-33">
	<div class="blog-content-box">
       <h1 class="blog-title">
	   <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h1>
             <div class="post-thumbnail">
 <?php the_post_thumbnail(array(450, 450)); ?>
 </div>
            <div class="entry-content color-1">
			<p><?php $content = get_the_content(); echo mb_strimwidth($content, 0, 150, '...');?></p>
			<a href="<?php the_permalink() ?>" class="btns btn-1c">Read more </a>
			</div></div>
       </div>
         <?php endwhile; ?>
    <?php endif; ?>
    </div>
</section>
</div>
<?php wp_reset_query(); ?>
</div>
<?php get_footer();?>