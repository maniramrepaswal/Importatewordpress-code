<?php 
    /*
    Template Name: How It Works
    */

    get_header();
?>

<?php 
    if(has_post_thumbnail()){
        $style = "";
        $attachement = get_the_post_thumbnail_url(get_the_ID(), 'full');
        $style = "background: url('".$attachement."') center center;";
        if(is_page('117'))
            $style .= "background-size: cover";
?>
<div class="banner-part min_height550" style="<?php echo $style;?>"></div>
<?php   }   ?>

<section class="margin_top_none padding_bottom_80">
    <?php
    if ( have_posts() ) :
        while ( have_posts() ) :
            the_post();
            get_template_part( 'template-parts/content', 'page' );
        endwhile;
    endif;
    ?>

    <?php 
        //getting custom post type data
        $number = get_field('circular_number');
        $args = array("post_type" => "how_it_works", "order_by" => "$number", "order" => "asc");
        $query = new WP_Query($args);
        if($query->have_posts()):
            $count = 1;
            echo "<div class='container'>";
            while($query->have_posts()):
                $query->the_post();
                
                if($count % 2 != 0){
        
                $step1 = "<div class='col-md-offset-5 col-md-30 col-md-45'><div class='f1_container how_it_work_proces'><div class='f1_card shadow'><div class='front face'><img src='".get_field('circular_image_front')."' alt='You Order' title='You Order'  class='img-responsive'></div><div class='back face center'><img src='". get_field('circular_image_back')."' alt='You Order' title='You Order'  class='img-responsive'></div></div></div></div>";
    
                $step2 = "<div class='col-md-20 col-sm-10'><div class='serial_number'><span>". get_field("circular_number")."</span></div></div>";
                
                $step3 = "<div class='col-md-offset-5 col-md-40 col-sm-45'><div class='having_meal_boxs order_proces'><h4>".get_field('textbox_heading')."</h4><p>".get_field('textbox_para')."</p></div></div>";
                
                }                
                else{
                    $step1 = "<div class='col-md-30 col-sm-45 how_it_responsive pull-right'><div class='f1_container how_it_work_proces'><div class='f1_card shadow'><div class='front face'><img src='".get_field('circular_image_front')."' alt='We Prepare' title='We Prepare' class='img-responsive'></div><div class='back face center'><img src='".get_field('circular_image_back')."' alt='We Prepare' title='We Prepare' class='img-responsive'></div></div></div></div>";
                    
                    $step2 = "<div class='col-md-offset-5 col-md-40 col-sm-45 pull-left'><div class='having_meal_boxs order_proces'><h4>".get_field('textbox_heading')."</h4><p>".get_field('textbox_para')."</p></div></div>";
                    
                    $step3 = "<div class='col-md-offset-5 col-md-20 col-sm-10'><div class='serial_number'><span>". get_field("circular_number")."</span></div></div>";
                }
    ?>
                 <div class="step_section">
                    <div class="row">
                        <?php 
                            echo $step1;
                            echo $step2; 
                            echo $step3;
                        ?>
                    </div>
                 </div>  
    <?php                               
            $count++;
            endwhile;
            echo "</div>";
            wp_reset_postdata();
        endif;
    ?>
		
    <?php if ( is_active_sidebar( 'page-sidebar' ) ) : ?>
        <div class="col-sm-4">
            <div id="sidebar">
                <?php dynamic_sidebar( 'page-sidebar' ); ?>
            </div>
        </div>
    <?php endif; ?>
</section>

<?php get_footer();?>