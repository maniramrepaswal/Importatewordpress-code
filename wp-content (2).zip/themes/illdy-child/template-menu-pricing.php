<?php 
    /* 
        Template Name: Menu & Pricing
    */
    get_header();
?>
<?php 
    if(has_post_thumbnail()){
        $style = "";
        $attachement = get_the_post_thumbnail_url(get_the_ID(), 'full');
        $style = 'background: url("'.$attachement.'") center center;';
?>
<?php 
        if(is_page(67)):
            echo "<div class='banner-part min_height550 hadding-banner-text' style='".$style."'><h2>".get_field('banner_text')."</h2></div>";
        else:
            echo "<div class='banner-part min_height550' style='".$style."'></div>";
        endif;
?>

<?php
    }
?>

<div class="menu_pricing_background">
    <div class="container">
        <?php 
            if(have_posts()):
                while(have_posts()):
                    the_post();
                    the_content();
                endwhile;
                wp_reset_postdata();
            endif;
         
            $args = array("post_type" => "product", "posts_per_page" => "-1", "order_by" => "date","post__not_in"=>array('264'));
            $query = new WP_Query($args);
            if($query->have_posts()):
                $count = 1;
                echo "<div class='row'>";
                while($query->have_posts()):
                    $query->the_post();
                    echo "<div class='col-sm-25'><div class='menu_pricing_box_main'><div class='having_meal_box menu_pricing_box'>".get_the_post_thumbnail(null, 'full', ['class' => 'img-responsive'])."</div><div class='color-1 view_button_menu'><a href='".get_the_permalink()."' class='btns btn-1c'>View</a></div></div><div class='menu_detail'><h4>".get_the_title()."</h4></div></div>";
                endwhile;
                echo "</div>";
            endif;
        ?>
    </div>
</div>

<?php get_footer();?>