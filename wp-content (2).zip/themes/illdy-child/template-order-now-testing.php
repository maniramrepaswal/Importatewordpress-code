<?php
/*
	Template Name: Order Now Testing
*/

print_r($_SESSION);
echo "cookie";
print_r($_COOKIE);

die;

if(is_user_logged_in()){
	$current_user	=	get_currentuserinfo();
	// pr($current_user);
}
// Programmatically Add Product to Cart
// for($i=195;$i<=200;$i++){
	/*
	global $woocommerce, $current_user;
	$current_user	=	get_currentuserinfo();
	$product_id	=	264;
	$quantity	=	1;
	$price		=	1;
	WC()->cart->add_to_cart( $product_id, $quantity,$price );
	*/
// }
/* 
$cat_id	=	wp_insert_term(
				'My Custom Cat',
				'product_cat',
				array(
					'description'	=>	'My Own Custom Category',
					'slug'	=>	'on-my-custom-cat',
				)
			);

echo "<pre>";
print_r($cat_id);
echo "</pre>"; */

