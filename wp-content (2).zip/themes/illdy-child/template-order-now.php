<?php 
    /* Template Name: Order Now */

    if(!is_user_logged_in()){
        wp_redirect(get_page_link(231));
    }

    get_header();
?>

    <?php 
    /*$args = array(
      'orderby' => 'id',
      'hide_empty'=> 0  );
  $categories = get_categories($args);
  foreach ($categories as $cat) {
    echo $cat->name;
        echo '<div style="width:20%;float:left;">';
        
        $args2= array("orderby"=>'name', "category" => $cat->cat_ID); // Get Post from each Sub-Category
        $posts_in_category = get_posts($args2);
        foreach($posts_in_category as $current_post) {
            echo '<span>';
            ?>
            <li type='none' style='list-style-type: none !important;'><a href="<?=$current_post->guid;?>"><?='+ '.$current_post->post_title;?></a></li>
            <?php
            echo '</span>';
        }
        echo '</div>';
    }*/
?>


<?php 
    if(has_post_thumbnail()){
        $style = "";
        $attachement = get_the_post_thumbnail_url(get_the_ID(), 'full');
        $style = 'background: url("'.$attachement.'") center center;';
?>
<div class='banner-part min_height550' style='<?php echo $style;?>'></div>
<?php } ?>
<section class="order-now">
    <div class="container levels">
        <div class="row">
            <div class="col-md-offset-2 col-md-23 col-xs-25">
                <div class="level_step1 your_mial_box_main active_box">
                    <img src="<?php echo get_stylesheet_directory_uri()."/images/mail-active.png"?>" alt="" class="img-responsive">
                    <h4>About You</h4>
                </div>
            </div>
            <div class="col-md-offset-2 col-md-23 col-xs-25">
                <div class="level_step2 your_mial_box_main">
                    <img src="<?php echo get_stylesheet_directory_uri()."/images/meals-back.png"?>" alt="" class="img-responsive">
                    <h4>Your Meals</h4>
                </div>
            </div>
            <div class="col-md-offset-2 col-md-23 col-xs-25">
                <div class="level_step3 your_mial_box_main">
                    <img src="<?php echo get_stylesheet_directory_uri()."/images/meals-back.png"?>" alt="" class="img-responsive">
                    <h4>Additional</h4>
                </div>
            </div>
            <div class="col-md-offset-2 col-md-23 col-xs-25">
                <div class="level_step4 your_mial_box_main">
                    <img src="<?php echo get_stylesheet_directory_uri()."/images/meals-back.png"?>" alt="" class="img-responsive">
                    <h4>Delivery</h4>
                </div>
            </div>
        </div>
    </div>

    
    <?php echo do_shortcode('[on_order_now]');?>
</section>

<?php get_footer();?>