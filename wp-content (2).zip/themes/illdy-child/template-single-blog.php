<?php 
    /*
    Template Name: single blog
    */
    get_header();

   
?>
<?php 
    if(has_post_thumbnail()){
        $style = "";
        $attachement = get_the_post_thumbnail_url(get_the_ID(), 'full');
        $style = "background: url('".$attachement."') center center;";
        if(is_page('117'))
            $style .= "background-size: cover";
?>
<div class="banner-part min_height550" style="<?php echo $style;?>"></div>
<?php   }   ?>
<div class="container">
<div class="row">
<div class="col-sm-100">
<div class="full-blog-section">
<div id="main-content" class="main-content">

    <div id="primary" class="content-area">
        <div id="content" class="site-content" role="main">
            <?php
                // Start the Loop.
                while ( have_posts() ) : the_post();

                    // Include the page content template.
                    get_template_part( 'content', 'page' );

                endwhile;
            ?>
        </div><!-- #content -->
    </div><!-- #primary -->
</div><!-- #main-content -->

 
<h2><?php the_title(); ?></h2>
<p><?php the_content();?></p>
</div></div></div></div>

		<?php get_footer();?>