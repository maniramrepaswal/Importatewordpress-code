<?php
/**
 * Update Weight Goal
 *
 * OVERIDDEN
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
global $post;
$meta_value = [];
$prev_value = "";
$weight_history = get_post_meta(156, 'userWeight');

$post_id = get_the_ID();
$meta_key = "userWeight";

if(isset($_REQUEST["user_weight_submit"])){
    if(!is_numeric($_REQUEST["user_weight"])){
        return;
    }
    
    $d = new DateTime('now');
    $date = $d->format('F jS Y');
    
    array_pop($_REQUEST);
    extract($_REQUEST);
    
    $temp = $date."-".$_REQUEST["user_weight"]."-".$_REQUEST["user_weight_unit"];
    
    if(empty($weight_history)){        
        array_push($meta_value, $temp);
        update_post_meta($post_id, $meta_key, wp_slash(json_encode($meta_value)));
    }
    else{
        $prev_value = $weight_history[0];
        $prev_value_arr = json_decode($prev_value);
        array_push($prev_value_arr, $temp);
        update_post_meta($post_id, $meta_key, wp_slash(json_encode($prev_value_arr)), $prev_value);
    }
}
?>
<div class="col-sm-100">
    <div class="enter-weight">
        <p class="greeting">Enter your weight</p>
        <form action="" class="form-horizontal" method="post">
            <fieldset>
                <div class="form-group">
                    <div class="col-sm-39">
                           <input type="text" placeholder="Enter Weight" name="user_weight" id="user_weight" class="form-control" pattern="^\d+(\.\d{1,2})?$" title="Only Numbers. Two numbers after decimal." style="height:50px;">
                    </div>
                    <div class="col-sm-39">
                        <select name="user_weight_unit" id="" class="form-control" style="height:50px;">
                            <option value="kilograms">Kilograms</option>
                            <option value="stones">Stones</option>
                        </select>
                    </div>
                    <div class="col-sm-22">
					<div class="color-1"><button class="btns btn-1c" style="padding: 0px;width: auto;; margin:0 !important;">
                        <input style="background:none; padding:0; border:none; text-transform: uppercase;" type="submit" name="user_weight_submit" id="user_weight_submit" value="Submit Weight">
						</button></div>
						
                    </div>
                </div>
            </fieldset>
        </form>
    </div>
    <div class="weight-history mt-10">
        <table class="woocommerce-orders-table woocommerce-MyAccount-orders shop_table shop_table_responsive my_account_orders account-orders-table">
            <tr>
                <th class="woocommerce-orders-table__header">S.No</th>
                <th class="woocommerce-orders-table__header">Date</th>
                <th class="woocommerce-orders-table__header">Weight</th>
            </tr>
            <?php 
                $weight_history = get_post_meta(156, 'userWeight');
                if(empty($weight_history)){?>
            <tr class="woocommerce-orders-table__row">
                <td colspan="3"><strong>No Weight History</strong></td>
            </tr>
            <?php 
                }else{
                $arr = json_decode($weight_history[0]);
                $count = 1;
                foreach($arr as $a){
                    $temp1 = explode("-", $a);
            ?>
            <tr class="woocommerce-orders-table__row">
                <td class="woocommerce-orders-table__cell"><?php echo $count;?></td>
                <td class="woocommerce-orders-table__cell"><?php echo $temp1[0];?></td>
                <td class="woocommerce-orders-table__cell"><?php echo $temp1[1]." ".$temp1[2];?></td>
            </tr>
            <?php $count++;}}?>
        </table>
    </div>
</div>