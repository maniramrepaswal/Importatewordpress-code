<?php
/**
 * Order details
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/order/order-details.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 3.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! $order = wc_get_order( $order_id ) ) {
	return;
}

$order_items           = $order->get_items( apply_filters( 'woocommerce_purchase_order_item_types', 'line_item' ) );
$show_purchase_note    = $order->has_status( apply_filters( 'woocommerce_purchase_note_order_statuses', array( 'completed', 'processing' ) ) );
$show_customer_details = is_user_logged_in() && $order->get_user_id() === get_current_user_id();
$downloads             = $order->get_downloadable_items();
$show_downloads        = $order->has_downloadable_item() && $order->is_download_permitted();



if ( $show_downloads ) {
	wc_get_template( 'order/order-downloads.php', array( 'downloads' => $downloads, 'show_title' => true ) );
}
?>
<section class="woocommerce-order-details">
	<h2 class="woocommerce-order-details__title"><?php _e( 'Order details', 'woocommerce' ); ?></h2>

	<table class="woocommerce-table woocommerce-table--order-details shop_table order_details">

		<thead>
			<tr>
				<th class="woocommerce-table__product-name product-name"><?php _e( 'Product', 'woocommerce' ); ?></th>
				<th class="woocommerce-table__product-table product-total"><?php _e( 'Total', 'woocommerce' ); ?></th>
			</tr>
		</thead>

		<tbody>
			<?php
				foreach ( $order_items as $item_id => $item ) {
					$product_quantity	=	$item->get_quantity();
					for($i=1;$i<=$product_quantity;$i++){
						$product = apply_filters( 'woocommerce_order_item_product', $item->get_product(), $item );

						wc_get_template( 'order/order-details-item.php', array(
							'order'			     => $order,
							'item_id'		     => $item_id,
							'item'			     => $item,
							'show_purchase_note' => $show_purchase_note,
							'purchase_note'	     => $product ? $product->get_purchase_note() : '',
							'product'	         => $product,
							'product_quantity'	 => $product_quantity,
						) );
					}
				}
			?>
			<?php do_action( 'woocommerce_order_items_table', $order ); ?>
			<?php
				foreach ($order->get_fees() as $fee_item_id => $fee_item) {
					$order_datas['fee_lines'][] = array(
						'id' => $fee_item_id,
						'title' => $fee_item['name'],
						'tax_class' => (!empty($fee_item['tax_class']) ) ? $fee_item['tax_class'] : null,
						'total' => wc_format_decimal($order->get_line_total($fee_item), $dp),
						'total_tax' => wc_format_decimal($order->get_line_tax($fee_item), $dp),
					);
				}
			?>
			<tr class="<?php echo esc_attr( apply_filters( 'woocommerce_order_item_class', 'woocommerce-table__line-item order_item', $item, $order ) ); ?>">
				<td class="woocommerce-table__product-name product-name">
					<?php echo $order_datas['fee_lines'][0]['title']; ?>
				</td>
				<td class="woocommerce-table__product-total product-total">
					<?php echo get_woocommerce_currency_symbol().''.$order_datas['fee_lines'][0]['total']; ?>
				</td>
			</tr>
			<tr class="<?php echo esc_attr( apply_filters( 'woocommerce_order_item_class', 'woocommerce-table__line-item order_item', $item, $order ) ); ?>">
				<th class="woocommerce-table__product-name product-name">
					Total: 
				</th>
				<td class="woocommerce-table__product-total product-total">
					<?php echo get_woocommerce_currency_symbol().''.$order->get_total(); ?>
				</td>
			</tr>
			<tr>
			<?php 
				$order_id	=	$order->get_id(); 
				$last_id	=	get_post_meta($order_id,'last_id',true);
				if(!empty($last_id)){
					global $wpdb,$table_name;
					$tb_name	=	$wpdb->prefix . 'oN_order_data';
					$sql		=	"SELECT * FROM $tb_name where id='$last_id'";
					$data		=	$wpdb->get_row($sql,ARRAY_A);
					$order_data	=	json_decode($data['order_data']);
					echo "<table class='woocommerce shop_table'>";
					if(!empty($order_data->dietgoals)){
						echo "<tr><th>Your Selected Diet Goals are: </th>";
						/*echo "</tr>";*/
						echo "<td>";
						foreach($order_data->dietgoals as $v){
							echo ucfirst(explode('-',$v)[1]).', ';
						}
						echo "</td>";
						/*echo "</ul></li>";*/
                        echo "</tr>";
					}
					if(!empty($order_data->weight)){
						echo "<tr><th>Your Weight is: </th><td> ".$order_data->weight."</td></tr>";
					}
					if(!empty($order_data->stp2_val)){
						echo "<tr><th>Your Selected Package is: </th>";
						$da	=	explode(':',$order_data->stp2_val);
						echo "<td> ".$da[0]." Meals per Day for ".$da[1]." Days worth ".get_woocommerce_currency_symbol()."".$da[2];
						echo "</td></tr>";
					}
					if(!empty($order_data->stp3_p_array)){
						echo "<tr><th>Your selected meals are: </th>";
						/*echo "<ul>";*/
						echo "<td>";
						echo "<table class='aboutYouMealsTable'><th></th>";
						$key	=	1;
						$l		=	1;
						for($i=1;$i<=$da[0];$i++){
							echo "<th>Meal ".$i."</th>";
						}
						foreach($order_data->stp3_p_array as $k=>$v){
							if($key == 1){ echo "<tr><th>Day ".($l)."</th>"; }
							echo "<td>".ucfirst(get_the_title($v))."</td>"; 	
							if(($k+1)%$da[0] == 0){
								$l++;
								if($l <= $da[1])
									echo "</tr><tr><th>Day ".($l)."</th>";
								$key	=	1;
							}
							$key++;
						};
						echo	"</table>";
						/* foreach($order_data->stp3_p_array as $v){
							echo ucfirst(get_the_title($v)).', ';
						} */
						echo "</td>";
						/*echo "</ul></li>";*/
                        echo "</tr>";
					}
					if(!empty($order_data->stp4_data)){
						foreach($order_data->stp4_data as $key=>$val){
							echo  "<tr><th>".ucfirst($val->title).": </th>";
							echo "<td>";
							foreach($val->opts as $k=>$v){
								echo $v->qty." ".ucfirst($v->title).", ";
							}
							echo "for ".get_woocommerce_currency_symbol()."".$val->total."</td></tr>";
						}
					}
					/* if(!empty($order_data->stp4_pp_qty)){
						echo "<tr><th>Protein Pancakes: </th><td>".$order_data->stp4_pp_qty." ".ucfirst($order_data->stp4_pp_option)." for ".get_woocommerce_currency_symbol()."".(int)($order_data->stp4_pp_price)*(int)($order_data->stp4_pp_qty)."</td></tr>";
					}
					if(!empty($order_data->stp4_pj_price)){
						$pj_price	=	0;
						echo  "<tr><th>Pressed Juices: </th><td>";
						if(!empty($order_data->stp4_pj_gp)){ 
							echo $order_data->stp4_pj_gp." Green Power"; 
							$pj_price 	+= 	(int)$order_data->stp4_pj_gp; 
						}
						if(!empty($order_data->stp4_pj_br)){ 
							echo ", ".$order_data->stp4_pj_gp." Blood Red"; 
							$pj_price 	+= 	(int)$order_data->stp4_pj_br; 
						}
						if(!empty($order_data->stp4_pj_dp)){ 
							echo ", ".$order_data->stp4_pj_gp." Divine Purple"; 
							$pj_price 	+= 	(int)$order_data->stp4_pj_dp; 
						}
						if(!empty($order_data->stp4_pj_t)){ 
							echo ", ".$order_data->stp4_pj_gp." Tropical"; 
							$pj_price 	+= 	(int)$order_data->stp4_pj_t; 
						}
						echo " for ".get_woocommerce_currency_symbol()."".$pj_price*(int)($order_data->stp4_pj_price)."</td></tr>";
					} */
					if(!empty($order_data->stp4_vegi)){
						echo "<tr><th>Vegetables Selected: </th><td>".$order_data->stp4_vegi."</td></tr>";
					}
					if(!empty($order_data->stp4_times)){
						echo "<tr><th>Deliveries per day Selected: </th><td>".$order_data->stp4_times."</td></tr>";
					}
					if(!empty($order_data->stp5_allergy_1) || !empty($order_data->stp5_allergy_2) || !empty($order_data->stp5_allergy_3) || !empty($order_data->stp5_allergy_4) || !empty($order_data->stp5_allergy_5)){
						echo "<tr><th>Allergy Selected: </th><td>";
						if($order_data->stp5_allergy_1)
							echo $order_data->stp5_allergy_1;
						if($order_data->stp5_allergy_2)
							echo ", ".$order_data->stp5_allergy_2;
						if($order_data->stp5_allergy_3)
							echo ", ".$order_data->stp5_allergy_3;
						if($order_data->stp5_allergy_4)
							echo ", ".$order_data->stp5_allergy_4;
						if($order_data->stp5_allergy_5)
							echo ", ".$order_data->stp5_allergy_5;
						/*echo "</ul></li>";*/
                        echo "</td></tr>";
					}
					if(!empty($order_data->step6_array)){
						echo "<tr><th colspan='2'>Order Form Details are: </th></tr>";
						echo "<tr><th>Delivery selected for total weeks: </th><td>".$order_data->step6_array->weeks_count."</td></tr>";
						echo "<tr><th>Email Address: </th><td>".$order_data->step6_array->email_add."</td></tr>";
						echo "<tr><th>Address: </th><td>".$order_data->step6_array->add_line1."".$order_data->step6_array->add_line2."</td></tr>";
						echo "<tr><th>City: </th><td>".$order_data->step6_array->add_city."</td></tr>";
						echo "<tr><th>Country: </th><td>".$order_data->step6_array->add_country."</td></tr>";
						echo "<tr><th>Postcode: </th><td>".$order_data->step6_array->add_postcode."</td></tr>";
						echo "<tr><th>Mobile Number: </th><td>".$order_data->step6_array->mob_num."</td></tr>";
						if(!empty($order_data->step6_array->delivery_time))
							echo "<tr><th>Delivery time: </th><td>".$order_data->step6_array->delivery_time."</td></tr>";
						/*echo "</ul></li>";*/
					}
					echo "</table>";
				}
			?>
			</tr>
		</tbody>

		<tfoot>
			<?php
				foreach ( $order->get_order_item_totals() as $key => $total ) {
					?>
					<tr>
						<th scope="row"><?php echo $total['label']; ?></th>
						<td><?php echo $total['value']; ?></td>
					</tr>
					<?php
				}
			?>
			<?php if ( $order->get_customer_note() ) : ?>
				<tr>
					<th><?php _e( 'Note:', 'woocommerce' ); ?></th>
					<td><?php echo wptexturize( $order->get_customer_note() ); ?></td>
				</tr>
			<?php endif; ?>
		</tfoot>
	</table>

	<?php do_action( 'woocommerce_order_details_after_order_table', $order ); ?>
</section>

<?php
if ( $show_customer_details ) {
	wc_get_template( 'order/order-details-customer.php', array( 'order' => $order ) );
}
