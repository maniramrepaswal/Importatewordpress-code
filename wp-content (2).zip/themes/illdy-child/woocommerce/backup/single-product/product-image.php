<?php
    if ( ! defined( 'ABSPATH' ) ) {
	   exit;
    }
	
    global $post, $product;
    $post_thumbnail_id = get_post_thumbnail_id( $post->ID );
    $full_size_image   = wp_get_attachment_image_src( $post_thumbnail_id, 'full' );
    
    if(has_post_thumbnail()):
		$imgAlt = get_post_meta($post_thumbnail_id,'_wp_attachment_image_alt', true);
?>
<div class="col-sm-40">
    <div class="having_meal_box view_full_img"> 
        <img src="<?php echo $full_size_image[0];?>" alt="<?php echo $imgAlt; ?>" class="img-responsive">
    </div>
</div>
<?php endif; ?>