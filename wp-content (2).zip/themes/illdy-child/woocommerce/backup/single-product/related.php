<?php
/**
 * Related Products
 *
 * OVERIDDEN
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( $related_products ) : ?>

	<div class="menu_pricing_background">
        <div class="container">
            <div class="row">
                <div class="col-sm-100">
                    <div class="headding-text-part">
                        <h2><?php esc_html_e( 'Related Foods', 'woocommerce' ); ?></h2>
                    </div>
                </div>
            </div>
        
		

		<?php woocommerce_product_loop_start(); ?>

			<?php foreach ( $related_products as $related_product ) : ?>

				<?php
				 	$post_object = get_post( $related_product->get_id() );

					setup_postdata( $GLOBALS['post'] =& $post_object );

					wc_get_template_part( 'content', 'product' ); ?>

			<?php endforeach; ?>

		<?php woocommerce_product_loop_end(); ?>
        </div>
	</div>

<?php endif;

wp_reset_postdata();
