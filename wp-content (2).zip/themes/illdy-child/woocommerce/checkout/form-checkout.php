<?php
/**
 * Checkout Form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/form-checkout.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

wc_print_notices();

do_action( 'woocommerce_before_checkout_form', $checkout );

// If checkout registration is disabled and not logged in, the user cannot checkout
if ( ! $checkout->is_registration_enabled() && $checkout->is_registration_required() && ! is_user_logged_in() ) {
	echo apply_filters( 'woocommerce_checkout_must_be_logged_in_message', __( 'You must be logged in to checkout.', 'woocommerce' ) );
	return;
}

?>

<form name="checkout" method="post" class="checkout woocommerce-checkout" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data">

	<?php if ( $checkout->get_checkout_fields() ) : ?>

		<?php do_action( 'woocommerce_checkout_before_customer_details' ); ?>

		<div class="col2-set" id="customer_details">
			<div class="col-1">
				<?php do_action( 'woocommerce_checkout_billing' ); ?>
			</div>

			<div class="col-2">
				<?php do_action( 'woocommerce_checkout_shipping' ); ?>
			</div>
		</div>

		<?php do_action( 'woocommerce_checkout_after_customer_details' ); ?>

	<?php endif; ?>

	<h3 id="order_review_heading"><?php _e( 'Your order', 'woocommerce' ); ?></h3>
<table class="woocommerce-table woocommerce-table--order-details shop_table order_details">
<tbody>
	<tr>
	<?php 
		$last_id	=	$_COOKIE['lastid'];
		if(!empty($last_id)){
			global $wpdb,$table_name;
			$tb_name	=	$wpdb->prefix . 'oN_order_data';
			$sql		=	"SELECT * FROM $tb_name where id='$last_id'";
			$data		=	$wpdb->get_row($sql,ARRAY_A);
			$order_data	=	json_decode($data['order_data']);
			echo "<table class='woocommerce shop_table'>";
			if(!empty($order_data->dietgoals)){
				echo "<tr><th>Your Selected Diet Goals are: </th>";
				/*echo "</tr>";*/
				echo "<td>";
				foreach($order_data->dietgoals as $v){
					echo ucfirst(explode('-',$v)[1]).', ';
				}
				echo "</td>";
				/*echo "</ul></li>";*/
				echo "</tr>";
			}
			if(!empty($order_data->weight)){
				echo "<tr><th>Your Weight is: </th><td> ".$order_data->weight."</td></tr>";
			}
			if(!empty($order_data->stp2_val)){
				echo "<tr><th>Your Selected Package is: </th>";
				$da	=	explode(':',$order_data->stp2_val);
				echo "<td> ".$da[0]." Meals per Day for ".$da[1]." Days worth ".get_woocommerce_currency_symbol()."".$da[2];
				echo "</td></tr>";
			}
			if(!empty($order_data->stp3_p_array)){
				echo "<tr><th>Your selected meals are: </th>";
				/*echo "<ul>";*/
				echo "<td>";
				echo "<table class='aboutYouMealsTable'><th></th>";
				$key	=	1;
				$l		=	1;
				for($i=1;$i<=$da[0];$i++){
					echo "<th>Meal ".$i."</th>";
				}
				foreach($order_data->stp3_p_array as $k=>$v){
					if($key == 1){ echo "<tr><th>Day ".($l)."</th>"; }
					echo "<td>".ucfirst(get_the_title($v))."</td>"; 	
					if(($k+1)%$da[0] == 0){
						$l++;
						if($l <= $da[1])
							echo "</tr><tr><th>Day ".($l)."</th>";
						$key	=	1;
					}
					$key++;
				};
				echo	"</table>";
				/* foreach($order_data->stp3_p_array as $v){
					echo ucfirst(get_the_title($v)).', ';
				} */
				echo "</td>";
				/*echo "</ul></li>";*/
				echo "</tr>";
			}
			if(!empty($order_data->stp4_data)){
				foreach($order_data->stp4_data as $key=>$val){
					echo  "<tr><th>".ucfirst($val->title).": </th>";
					echo "<td>";
					foreach($val->opts as $k=>$v){
						echo $v->qty." ".ucfirst($v->title).", ";
					}
					echo "for ".get_woocommerce_currency_symbol()."".$val->total."</td></tr>";
				}
			}
			/* if(!empty($order_data->stp4_pp_qty)){
				echo "<tr><th>Protein Pancakes: </th><td>".$order_data->stp4_pp_qty." ".ucfirst($order_data->stp4_pp_option)." for ".get_woocommerce_currency_symbol()."".(int)($order_data->stp4_pp_price)*(int)($order_data->stp4_pp_qty)."</td></tr>";
			}
			if(!empty($order_data->stp4_pj_price)){
				$pj_price	=	0;
				echo  "<tr><th>Pressed Juices: </th><td>";
				if(!empty($order_data->stp4_pj_gp)){ 
					echo $order_data->stp4_pj_gp." Green Power"; 
					$pj_price 	+= 	(int)$order_data->stp4_pj_gp; 
				}
				if(!empty($order_data->stp4_pj_br)){ 
					echo ", ".$order_data->stp4_pj_gp." Blood Red"; 
					$pj_price 	+= 	(int)$order_data->stp4_pj_br; 
				}
				if(!empty($order_data->stp4_pj_dp)){ 
					echo ", ".$order_data->stp4_pj_gp." Divine Purple"; 
					$pj_price 	+= 	(int)$order_data->stp4_pj_dp; 
				}
				if(!empty($order_data->stp4_pj_t)){ 
					echo ", ".$order_data->stp4_pj_gp." Tropical"; 
					$pj_price 	+= 	(int)$order_data->stp4_pj_t; 
				}
				echo " for ".get_woocommerce_currency_symbol()."".$pj_price*(int)($order_data->stp4_pj_price)."</td></tr>";
			} */
			if(!empty($order_data->stp4_vegi)){
				echo "<tr><th>Vegetables Selected: </th><td>".$order_data->stp4_vegi."</td></tr>";
			}
			if(!empty($order_data->stp4_times)){
				echo "<tr><th>Deliveries per Week Selected: </th><td>".$order_data->stp4_times."</td></tr>";
			}
			if(!empty($order_data->stp5_allergy_1) || !empty($order_data->stp5_allergy_2) || !empty($order_data->stp5_allergy_3) || !empty($order_data->stp5_allergy_4) || !empty($order_data->stp5_allergy_5)){
				echo "<tr><th>Allergy Selected: </th><td>";
				if($order_data->stp5_allergy_1)
					echo $order_data->stp5_allergy_1;
				if($order_data->stp5_allergy_2)
					echo ", ".$order_data->stp5_allergy_2;
				if($order_data->stp5_allergy_3)
					echo ", ".$order_data->stp5_allergy_3;
				if($order_data->stp5_allergy_4)
					echo ", ".$order_data->stp5_allergy_4;
				if($order_data->stp5_allergy_5)
					echo ", ".$order_data->stp5_allergy_5;
				/*echo "</ul></li>";*/
				echo "</td></tr>";
			}
			if(!empty($order_data->step6_array)){
				echo "<tr><th colspan='2'>Order Form Details are: </th></tr>";
				echo "<tr><th>Delivery selected for total weeks: </th><td>".$order_data->step6_array->weeks_count."</td></tr>";
				echo "<tr><th>Email Address: </th><td>".$order_data->step6_array->email_add."</td></tr>";
				echo "<tr><th>Address: </th><td>".$order_data->step6_array->add_line1."".$order_data->step6_array->add_line2."</td></tr>";
				echo "<tr><th>City: </th><td>".$order_data->step6_array->add_city."</td></tr>";
				echo "<tr><th>Country: </th><td>".$order_data->step6_array->add_country."</td></tr>";
				echo "<tr><th>Postcode: </th><td>".$order_data->step6_array->add_postcode."</td></tr>";
				echo "<tr><th>Mobile Number: </th><td>".$order_data->step6_array->mob_num."</td></tr>";
				if(!empty($order_data->step6_array->delivery_time))
					echo "<tr><th>Delivery time: </th><td>".$order_data->step6_array->delivery_time."</td></tr>";
				/*echo "</ul></li>";*/
			}
			echo "</table>";
		}
	?>
	</tr>
</tbody>
</table>
	<?php do_action( 'woocommerce_checkout_before_order_review' ); ?>

	<div id="order_review" class="woocommerce-checkout-review-order">
		<?php do_action( 'woocommerce_checkout_order_review' ); ?>
	</div>

	<?php do_action( 'woocommerce_checkout_after_order_review' ); ?>

</form>

<?php do_action( 'woocommerce_after_checkout_form', $checkout ); ?>