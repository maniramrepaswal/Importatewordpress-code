<?php
/**
 * OVERIDDEN - from plugins to theme
 * The template for displaying product content in the single-product.php template.
 
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>

<?php
	/**
	 * woocommerce_before_single_product hook.
	 *
	 * @hooked wc_print_notices - 10
	 */
	 do_action( 'woocommerce_before_single_product' );

	 if ( post_password_required() ) {
	 	echo get_the_password_form();
	 	return;
	 }

?>

<div id="product-<?php the_ID(); ?>" <?php post_class(); ?>>

	<?php
		/**
		 * woocommerce_before_single_product_summary hook.
		 *
		 * @hooked woocommerce_show_product_sale_flash - 10
		 * @hooked woocommerce_show_product_images - 20
		 */
		do_action( 'woocommerce_before_single_product_summary' );
	?>

	<div class="col-sm-55 col-md-offset-5">
        <div class="menu_detail food-deatils-section">
		    <div class="food-hadding-section">
                <?php the_title( '<h1>', '</h1>' ); ?>
            </div>
            <div class='food-text-part'>
                <?php the_content(); ?>
            </div>
            <div class="food-order-section">
                <div class="food-order-number"> </div>
                <div class="form-group text-center color-1 food-order-sumbit">
                   <!--<a href="#!" type="submit" class="btns btn-1c">call to action</a>-->
                   <a href="<?php echo get_page_link(247)?>" type="submit" class="btns btn-1c">order now</a>
                </div>
            </div>
        </div>
	</div><!-- .summary -->
</div><!-- #product-<?php the_ID(); ?> -->