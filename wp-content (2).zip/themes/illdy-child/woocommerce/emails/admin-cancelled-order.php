<?php
/**
 * Admin cancelled order email
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/emails/admin-cancelled-order.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates/Emails
 * @version 2.5.0
 */

 if ( ! defined( 'ABSPATH' ) ) {
 	exit;
 }

 /**
  * @hooked WC_Emails::email_header() Output the email header
  */
 do_action( 'woocommerce_email_header', $email_heading, $email ); ?>

 <p><?php printf( __( 'Oh No! What happened? <br><br> Sorry to hear you want to cancel your order. Don�t worry � in case you change your mind, we have kept the details in your account.<br><br>
The order #%1$d from %2$s has been cancelled. The order was as follows:', 'woocommerce' ), $order->get_order_number(), $order->get_formatted_billing_full_name() ); ?></p>


 <?php

 /**
  * @hooked WC_Emails::order_details() Shows the order details table.
  * @hooked WC_Structured_Data::generate_order_data() Generates structured data.
  * @hooked WC_Structured_Data::output_structured_data() Outputs structured data.
  * @since 2.5.0
  */
 do_action( 'woocommerce_email_order_details', $order, $sent_to_admin, $plain_text, $email );

 /**
  * @hooked WC_Emails::order_meta() Shows order meta data.
  */
 do_action( 'woocommerce_email_order_meta', $order, $sent_to_admin, $plain_text, $email );

 /**
  * @hooked WC_Emails::customer_details() Shows customer details
  * @hooked WC_Emails::email_address() Shows email address
  */
 do_action( 'woocommerce_email_customer_details', $order, $sent_to_admin, $plain_text, $email );

?>
<span style="font-size: 18px;">Until next time�</span>
<h3 style="text-align: center;padding: 0 48px 48px 48px;font-size:18px;font-weight:normal;">See you soon amigo,<br />
Team Diets 2 Go
</h3>
<div class="social-link" style="text-align:center;"><a href="https://en-gb.facebook.com/pg/Diets2Go" target="_blank" style="display: inline-block;margin: 0px 3px;"><img alt="" height="50" src="<?php echo site_url();?>/wp-content/uploads/2018/02/icon11.png" width="50" /></a><a href="https://twitter.com/Diets2go" target="_blank" style="display: inline-block;margin: 0px 3px;"> <img alt="" height="50" src="<?php echo site_url();?>/wp-content/uploads/2018/02/icon12.png" width="50" /> </a><a href="https://www.instagram.com/diets2go/" target="_blank" style="display: inline-block;margin: 0px 3px;"><img alt="" height="50" src="<?php echo site_url();?>/wp-content/uploads/2018/02/icon13.png" width="50" /></a><br />
<img src="https://gallery.mailchimp.com/04441d974880c06f94a393309/images/bc5c75d3-f8c1-4867-8041-089e620d67b6.jpg" /> <img src="https://gallery.mailchimp.com/04441d974880c06f94a393309/images/b947d3eb-f144-4154-9b81-a9d7f8a16039.jpg" /><br />
<img src="https://gallery.mailchimp.com/04441d974880c06f94a393309/images/a5684b87-a485-4729-ba71-39c5c2ad4894.jpg" /></div>

 <?php 
  /**
  * @hooked WC_Emails::email_footer() Output the email footer
  */
 //do_action( 'woocommerce_email_footer', $email );
