<?php
/**
 * Order details table shown in emails.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/emails/email-order-details.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates/Emails
 * @version     3.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$text_align = is_rtl() ? 'right' : 'left';

do_action( 'woocommerce_email_before_order_table', $order, $sent_to_admin, $plain_text, $email ); ?>

<?php if ( ! $sent_to_admin ) : ?>
	<h2><?php printf( __( 'Order #%s', 'woocommerce' ), $order->get_order_number() ); ?> (<?php printf( '<time datetime="%s">%s</time>', $order->get_date_created()->format( 'c' ), wc_format_datetime( $order->get_date_created() ) ); ?>)</h2>
<?php else : ?>
	<h2><a class="link" href="<?php echo esc_url( admin_url( 'post.php?post=' . $order->get_id() . '&action=edit' ) ); ?>"><?php printf( __( 'Order #%s', 'woocommerce' ), $order->get_order_number() ); ?></a> (<?php printf( '<time datetime="%s">%s</time>', $order->get_date_created()->format( 'c' ), wc_format_datetime( $order->get_date_created() ) ); ?>)</h2>
<?php endif; ?>

<div style="margin-bottom: 40px;">
	<table class="td" cellspacing="0" cellpadding="6" style="width: 100%; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;" border="1">
		<thead>
			<tr>
				<th class="td" scope="col" style="text-align:<?php echo $text_align; ?>;"><?php _e( 'Product', 'woocommerce' ); ?></th>
				<th class="td" scope="col" style="text-align:<?php echo $text_align; ?>;"><?php _e( 'Quantity', 'woocommerce' ); ?></th>
				<th class="td" scope="col" style="text-align:<?php echo $text_align; ?>;"><?php _e( 'Price', 'woocommerce' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php echo wc_get_email_order_items( $order, array(
				'show_sku'      => $sent_to_admin,
				'show_image'    => false,
				'image_size'    => array( 32, 32 ),
				'plain_text'    => $plain_text,
				'sent_to_admin' => $sent_to_admin,
			) ); ?>
			<?php
				$order_id	=	$order->get_id(); 
				$last_id	=	get_post_meta($order_id,'last_id',true);
				if(!empty($last_id)){
					global $wpdb,$table_name;
					$tb_name	=	$wpdb->prefix . 'oN_order_data';
					$sql		=	"SELECT * FROM $tb_name where id='$last_id'";
					$data		=	$wpdb->get_row($sql,ARRAY_A);
					$order_data	=	json_decode($data['order_data']);
					if(!empty($order_data->stp2_val)){
						$da	=	explode(':',$order_data->stp2_val);
					}
					if(!empty($order_data->dietgoals)){
						echo "<tr><th>Diet Goal: </th>";
						/*echo "</tr>";*/
						echo "<td>";
						foreach($order_data->dietgoals as $v){
							echo ucfirst(explode('-',$v)[1]).', ';
						}
						echo "</td>";
						/*echo "</ul></li>";*/
						echo "</tr>";
					}
					if(!empty($order_data->weight)){
						echo "<tr><th>Your Weight is: </th><td> ".$order_data->weight."</td></tr>";
					}
					if(!empty($order_data->stp3_p_array)){
						echo "<tr><th colspan='3'>Selected meals are: </th></tr>";
						echo "<tr>";
						echo "<td colspan='3'>";
						echo "<table class='aboutYouMealsTable'><th></th>";
						$key	=	1;
						$l		=	1;
						for($i=1;$i<=$da[0];$i++){
							echo "<th>Meal ".$i."</th>";
						}
						foreach($order_data->stp3_p_array as $k=>$v){
							if($key == 1){ echo "<tr><th>Day ".($l)."</th>"; }
							echo "<td>".ucfirst(get_the_title($v))."</td>"; 	
							if(($k+1)%$da[0] == 0){
								$l++;
								if($l <= $da[1])
									echo "</tr><tr><th>Day ".($l)."</th>";
								$key	=	1;
							}
							$key++;
						};
						echo	"</table>";
						echo "</td>";
                        echo "</tr>";
					}
					if(!empty($order_data->stp4_data)){
						foreach($order_data->stp4_data as $key=>$val){
							echo  "<tr><th>".ucfirst($val->title).": </th>";
							echo "<td>";
							foreach($val->opts as $k=>$v){
								echo $v->qty." ".ucfirst($v->title).", ";
							}
							echo "for ".get_woocommerce_currency_symbol()."".$val->total."</td></tr>";
						}
					}
					if(!empty($order_data->stp4_vegi)){
						echo "<tr><th>Vegetables Selected: </th><td>".$order_data->stp4_vegi."</td></tr>";
					}
					if(!empty($order_data->stp4_times)){
						echo "<tr><th>Deliveries per Week: </th><td>".$order_data->stp4_times."</td></tr>";
					}
					if(!empty($order_data->stp5_allergy_1) || !empty($order_data->stp5_allergy_2) || !empty($order_data->stp5_allergy_3) || !empty($order_data->stp5_allergy_4) || !empty($order_data->stp5_allergy_5)){
						echo "<tr><th>Allergy Selected: </th><td>";
						if($order_data->stp5_allergy_1)
							echo $order_data->stp5_allergy_1;
						if($order_data->stp5_allergy_2)
							echo ", ".$order_data->stp5_allergy_2;
						if($order_data->stp5_allergy_3)
							echo ", ".$order_data->stp5_allergy_3;
						if($order_data->stp5_allergy_4)
							echo ", ".$order_data->stp5_allergy_4;
						if($order_data->stp5_allergy_5)
							echo ", ".$order_data->stp5_allergy_5;
						/*echo "</ul></li>";*/
						echo "</td></tr>";
					}
                                      if(!empty($order_data->step6_array)){
				echo "<tr class='subheading'><th colspan='2'>Order Form Details are: </th></tr>";
				echo "<tr><th>Total Weeks Count: </th><td>".$order_data->step6_array->weeks_count."</td></tr>";
				echo "<tr><th>Email Address: </th><td>".$order_data->step6_array->email_add."</td></tr>";
				echo "<tr><th>Address: </th><td>".$order_data->step6_array->add_line1."".$order_data1->step6_array->add_line2."</td></tr>";
				echo "<tr><th>City: </th><td>".$order_data->step6_array->add_city."</td></tr>";
				echo "<tr><th>Country: </th><td>".$order_data->step6_array->add_country."</td></tr>";
				echo "<tr><th>Postcode: </th><td>".$order_data->step6_array->add_postcode."</td></tr>";
				echo "<tr><th>Mobile Number: </th><td>".$order_data->step6_array->mob_num."</td></tr>";
				if(!empty($order_data->step6_array->delivery_time))
					echo "<tr><th>Delivery Time: </th><td>".$order_data->step6_array->delivery_time."</td></tr>";
				/*echo "</ul></li>";*/
			}
				}
				?>
		</tbody>
		<tfoot>
			<?php
				if ( $totals = $order->get_order_item_totals() ) {
					$i = 0;
					foreach ( $totals as $total ) {
						$i++;
						?><tr>
							<th class="td" scope="row" colspan="2" style="text-align:<?php echo $text_align; ?>; <?php echo ( 1 === $i ) ? 'border-top-width: 4px;' : ''; ?>"><?php echo $total['label']; ?></th>
							<td class="td" style="text-align:<?php echo $text_align; ?>; <?php echo ( 1 === $i ) ? 'border-top-width: 4px;' : ''; ?>"><?php echo $total['value']; ?></td>
						</tr><?php
					}
				}
				if ( $order->get_customer_note() ) {
					?><tr>
						<th class="td" scope="row" colspan="2" style="text-align:<?php echo $text_align; ?>;"><?php _e( 'Note:', 'woocommerce' ); ?></th>
						<td class="td" style="text-align:<?php echo $text_align; ?>;"><?php echo wptexturize( $order->get_customer_note() ); ?></td>
					</tr><?php
				}
			?>
		</tfoot>
	</table>
</div>

<?php do_action( 'woocommerce_email_after_order_table', $order, $sent_to_admin, $plain_text, $email ); ?>
