<?php
/**
 * Orders
 *
 * Shows orders on the account page.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/orders.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 3.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
do_action( 'woocommerce_before_account_orders', $has_orders ); ?>

<?php if ( $has_orders ) : ?>

	<table class="woocommerce-orders-table woocommerce-MyAccount-orders shop_table shop_table_responsive my_account_orders account-orders-table">
		<thead>
			<tr>
				<?php foreach ( wc_get_account_orders_columns() as $column_id => $column_name ) : ?>
					<th class="woocommerce-orders-table__header woocommerce-orders-table__header-<?php echo esc_attr( $column_id ); ?>"><span class="nobr"><?php echo esc_html( $column_name ); ?></span></th>
				<?php endforeach; ?>
			</tr>
		</thead>

		<tbody>
			<?php foreach ( $customer_orders->orders as $customer_order ) :
				$order      = wc_get_order( $customer_order );
				$item_count = $order->get_item_count();
				$order_items = $order->get_items();
					// Iterating through each item in the order
					foreach ($order_items as $item_id => $item_data) {
						$product_name 	= 	$item_data['name'];
						$item_quantity 	= 	$order->get_item_meta($item_id, '_qty', true);
						$item_total 	= 	$order->get_item_meta($item_id, '_line_total', true);
						$item_price		=	$item_total/$item_quantity;
						$order_id		=	$order->get_id(); 
						$last_id		=	get_post_meta($order_id,'last_id',true);
					}	
				?>
				<tr class="woocommerce-orders-table__row woocommerce-orders-table__row--status-<?php echo esc_attr( $order->get_status() ); ?> order">
					<?php foreach ( wc_get_account_orders_columns() as $column_id => $column_name ) : ?>
						<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-<?php echo esc_attr( $column_id ); ?>" data-title="<?php echo esc_attr( $column_name ); ?>">
							<?php if ( has_action( 'woocommerce_my_account_my_orders_column_' . $column_id ) ) : ?>
								<?php do_action( 'woocommerce_my_account_my_orders_column_' . $column_id, $order ); ?>

							<?php elseif ( 'order-number' === $column_id ) : ?>
								<a href="<?php echo esc_url( $order->get_view_order_url() ); ?>">
									<?php echo _x( '#', 'hash before order number', 'woocommerce' ) . $order->get_order_number(); ?>
								</a>

							<?php elseif ( 'order-date' === $column_id ) : ?>
								<time datetime="<?php echo esc_attr( $order->get_date_created()->date( 'c' ) ); ?>"><?php echo esc_html( wc_format_datetime( $order->get_date_created() ) ); ?></time>

							<?php elseif ( 'order-status' === $column_id ) : ?>
								<?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?>

							<?php elseif ( 'order-total' === $column_id ) : ?>
								<?php
								/* translators: 1: formatted order total 2: total order items */
								printf( _n( '%1$s for %2$s item', '%1$s for %2$s items', $item_count, 'woocommerce' ), $order->get_formatted_order_total(), $item_count );
								?>

							<?php elseif ( 'order-actions' === $column_id ) : ?>
								<?php
								$actions = wc_get_account_orders_actions( $order );
								
								if ( ! empty( $actions ) ) {
									foreach ( $actions as $key => $action ) {
										echo '<a href="' . esc_url( $action['url'] ) . '" class="btns btn-1c ' . sanitize_html_class( $key ) . '">' . esc_html( $action['name'] ) . '</a>';
										if($key	==	'view'){
											echo '<a href="javascript:void(0);" class="pay woo_edit_button btns btn-1c">Edit</a>';
											echo '
											
											<form method="post" class="color-1">
											<button class="btns btn-1c reoder">
												<input type="hidden" name="p_name" value="'.$product_name.'">
												<input type="hidden" name="p_price" value="'.$item_price.'">
												<input type="hidden" name="p_qty" value="'.$item_count.'">
												<input type="hidden" name="last_id" value="'.$last_id.'">
												<input  type="submit" name="reorder" value="Re-Order">
												</button>
											</form>
											
											';
										}
									}
								}
								?>
								<div id="woo_edit_button" class="modal fade"  role="dialog" style="margin-top:180px;">
									<div class="modal-dialog">
										<!-- Modal content-->
										<div class="modal-content">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal">&times;</button>
												<h4 class="modal-title">Diets2Go</h4>
											</div>
											<div class="modal-body">
												<p>If you want to edit any order. Please Contact Diets2go Team.</p>
											</div>
											<div class="modal-footer">
												<button style="border: none;font-family: inherit;background: none;background-color:rgba(0, 0, 0, 0);background-image: none;cursor: pointer;display: inline-block;text-transform: uppercase;letter-spacing: 1px;outline: none;position: relative;-webkit-transition: all 0.3s;-moz-transition: all 0.3s;transition: all 0.3s;border: 2px solid #34c6f4;color: #34c6f4;font-size: 16px;border-radius: 4px;margin-left:2px;margin-right:2px;" type="button" class="woocommerce-button button" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>
								<script>
									jQuery(document).ready(function($){
										$(document).on("click",".woo_edit_button",function(){
											$("#woo_edit_button").modal("show");
										});
									});
								</script>
							<?php endif; ?>
						</td>
					<?php endforeach; ?>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>

	<?php do_action( 'woocommerce_before_account_orders_pagination' ); ?>

	<?php if ( 1 < $customer_orders->max_num_pages ) : ?>
		<div class="woocommerce-pagination woocommerce-pagination--without-numbers woocommerce-Pagination">
			<?php if ( 1 !== $current_page ) : ?>
				<a style="border: none;font-family: inherit;background: none;background-color:rgba(0, 0, 0, 0);background-image: none;cursor: pointer;display: inline-block;text-transform: uppercase;letter-spacing: 1px;outline: none;position: relative;-webkit-transition: all 0.3s;-moz-transition: all 0.3s;transition: all 0.3s;border: 2px solid #34c6f4;color: #34c6f4;font-size: 16px;border-radius: 4px;margin-left:2px;margin-right:2px;" class="woocommerce-button woocommerce-button--previous woocommerce-Button woocommerce-Button--previous button" href="<?php echo esc_url( wc_get_endpoint_url( 'orders', $current_page - 1 ) ); ?>"><?php _e( 'Previous', 'woocommerce' ); ?></a>
			<?php endif; ?>

			<?php if ( intval( $customer_orders->max_num_pages ) !== $current_page ) : ?>
				<a style="border: none;font-family: inherit;background: none;background-color:rgba(0, 0, 0, 0);background-image: none;cursor: pointer;display: inline-block;text-transform: uppercase;letter-spacing: 1px;outline: none;position: relative;-webkit-transition: all 0.3s;-moz-transition: all 0.3s;transition: all 0.3s;border: 2px solid #34c6f4;color: #34c6f4;font-size: 16px;border-radius: 4px;margin-left:2px;margin-right:2px;" class="woocommerce-button woocommerce-button--next woocommerce-Button woocommerce-Button--next button" href="<?php echo esc_url( wc_get_endpoint_url( 'orders', $current_page + 1 ) ); ?>"><?php _e( 'Next', 'woocommerce' ); ?></a>
			<?php endif; ?>
		</div>
	<?php endif; ?>

<?php else : ?>
	<div class="woocommerce-message woocommerce-message--info woocommerce-Message woocommerce-Message--info woocommerce-info">
		<!--<a class="woocommerce-Button button" href="<?php //echo esc_url( apply_filters( 'woocommerce_return_to_shop_redirect', wc_get_page_permalink( 'shop' ) ) ); ?>">
			<?php //_e( 'Go shop', 'woocommerce' ) ?>
		</a>-->
		<?php _e( 'No order has been made yet.', 'woocommerce' ); ?>
	</div>
<?php endif; ?>

<?php do_action( 'woocommerce_after_account_orders', $has_orders ); ?>
