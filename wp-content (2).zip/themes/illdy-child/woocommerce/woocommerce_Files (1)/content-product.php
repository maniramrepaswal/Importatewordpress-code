<?php
/**
 * The template for displaying product content within loops
 *
 * OVERIDDEN
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product;

// Ensure visibility
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}


?>
<div <?php post_class('col-sm-25'); ?>>
    <div class='having_meal_box menu_pricing_box'>
        <a href='<?php echo esc_url(get_the_permalink()); ?>'>
           <?php  echo $product->get_image();?>
        </a>
    </div>
    
    <div class="menu_detail">
        <?php echo '<h4 class="woocommerce-loop-product__title">' . get_the_title() . '</h4>';?>
    </div>

</div>