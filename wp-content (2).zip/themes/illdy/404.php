<?php
/**
 *  The template for dispalying the archive.
 *
 *  @package WordPress
 *  @subpackage illdy
 */
?>
<?php //get_header(); ?>
<?php


$page_subtitle = get_theme_mod( 'illdy_404_subtitle', esc_html__( 'OOOPS!', 'illdy' ) );
$page_content = get_theme_mod( 'illdy_404_content', esc_html__( 'OOOPS page not found', 'illdy' ) );
$page_button_label = get_theme_mod( 'illdy_404_button_label', esc_html__( 'Home', 'illdy' ) );

?>
<style>
	.btn_error_part {position: absolute;top: 60%;left: 0;right: 0;text-align: center;}
.content-404 img{ width:100%; height:auto;}
.row.error-page {position: relative;}
.btn_error { position:sticky;}
.error-page{ width:100%; display:inline-block;} 
body{ margin:0;}
.btns {cursor: pointer;padding: 12px 70px;display: inline-block;text-transform: uppercase;letter-spacing: 1px;outline: none;position: relative;transition: all 0.3s;
border: 2px solid #34c6f4;color: #34c6f4;font-size: 20px;border-radius: 4px;	text-decoration:none;}
.btn_error .btn-1c:hover, .btn-1c:active {    color: #34c6f4;}
.btn-1c::after {    width: 0%;    height: 100%;    top: 0;    left: 0;    background: #34c6f4;}
.btns::after {    content: '';    position: absolute;    z-index: -1;    -webkit-transition: all 0.3s;    -moz-transition: all 0.3s;    transition: all 0.3s;}
.btn-1c:hover, .btn-1c:active {    color: #fff !important;	    background: #34c6f4;}
.content-404 { background:url(http://www.diets2go.co.uk/wp-content/uploads/2018/02/error_banner.jpg); background-repeat: no-repeat; height: 100%; width: 100%;background-position: center; background-size: cover;}
</style>

<div class="container-fluid">
	    <div class="row error-page">
		<div class="content-404"></div>
		<div class="btn_error_part">
		<div class="btn_error">
	   <a href="<?php echo site_url() ?>" class="btns btn-1c"><?php echo esc_html( $page_button_label ) ?></a>
		</div></div></div>

	</div><!--/.row-->
</div><!--/.container-->
<?php //get_footer(); ?>
