<?php

// We will keep this class for backwards compatibility. The Illdy Companion plugin uses this class and if someone would update the theme but the companion they will run into a fatal error.
class Epsilon_Editor_Custom_Control extends Epsilon_Control_Text_Editor {

}